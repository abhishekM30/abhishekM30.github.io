package com.greenstar.addressService.service;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.skyscreamer.jsonassert.JSONAssert;
import org.springframework.beans.BeanUtils;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import com.greenstar.addressService.entity.AddressEntity;
import com.greenstar.addressService.modal.AddressModal;
import com.greenstar.addressService.repository.AddressRepository;

@RunWith(SpringRunner.class)
@WebMvcTest(value = AddressServiceImpl.class, secure = false)
public class AddressServiceTest {

	@MockBean
	private AddressRepository addressRepository;

	@Test
	public void getAddress() throws Exception {

		AddressEntity entity = new AddressEntity(1, "xxx", "pune", "MH", 411057, 77777);
		AddressModal modalObject = new AddressModal();
		Mockito.when(addressRepository.getOne(1l)).thenReturn(entity);
		BeanUtils.copyProperties(entity, modalObject);
		JSONAssert.assertEquals(modalObject.getAddressLine1(), entity.getAddressLine1(), false);
	}

	@Test
	public void getAllAddress() throws Exception {

		List<AddressEntity> mockList = new ArrayList<AddressEntity>();
		AddressEntity entity1 = new AddressEntity(1, "xxx", "pune", "MH", 411057, 987654321);
		AddressEntity entity2 = new AddressEntity(2, "qqq", "delhi", "Delhi", 110076, 123456789);
		mockList.add(entity1);
		mockList.add(entity2);
		List<AddressModal> mockModalList = new ArrayList<AddressModal>();

		for (AddressEntity e : mockList) {
			AddressModal modalObject = new AddressModal();
			BeanUtils.copyProperties(e, modalObject);
			mockModalList.add(modalObject);
		}

		Mockito.when(addressRepository.findAll()).thenReturn(mockList);

		JSONAssert.assertEquals(String.valueOf(mockModalList.get(0).getPinCode()),
				String.valueOf(mockList.get(0).getPinCode()), false);
	}

	@Test
	public void putAddress() throws Exception {
		AddressModal addressModal = new AddressModal(1, "xxx", "pune", "MH", 411057, 987654321);
		AddressEntity entity = new AddressEntity();
		BeanUtils.copyProperties(addressModal, entity);
		Mockito.when(addressRepository.saveAndFlush(entity)).thenReturn(entity);
		JSONAssert.assertEquals(entity.getAddressLine1(), addressModal.getAddressLine1(), false);

	}

}
