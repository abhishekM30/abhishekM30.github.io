package com.greenstar.addressService.controller;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpStatus;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.skyscreamer.jsonassert.JSONAssert;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.greenstar.addressService.modal.AddressModal;
import com.greenstar.addressService.service.AddressService;

@RunWith(SpringRunner.class)
@WebMvcTest(value = AddressController.class, secure = false)
public class AddressControllerTest {

	@Autowired
	private MockMvc mockMvc;

	@MockBean
	private AddressService addressService;

	@Test
	public void getAddress() throws Exception {

		AddressModal modal = new AddressModal(1, "xxx", "pune", "MH", 411057, 77777);
		Mockito.when(addressService.getAddress(Mockito.anyLong())).thenReturn(modal);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.get("/address/id/1").accept(MediaType.APPLICATION_JSON);
		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		String expected = "{addressId:1,addressLine1:xxx"
				+ ",district:pune,state:MH,pinCode:411057,emergencyContactNo:77777}";
		JSONAssert.assertEquals(expected, result.getResponse().getContentAsString(), false);
	}

	@Test
	public void getAllAddress() throws Exception {

		List<AddressModal> mockList = new ArrayList<AddressModal>();
		AddressModal mockModal1 = new AddressModal(1, "xxx", "pune", "MH", 411057, 987654321);
		AddressModal mockModal2 = new AddressModal(2, "yyy", "delhi", "Delhi", 110076, 123456789);
		mockList.add(mockModal1);
		mockList.add(mockModal2);
		Mockito.when(addressService.getAllAddress()).thenReturn(mockList);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.get("/address/all").accept(MediaType.APPLICATION_JSON);
		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		String expected = "[{addressId:1,addressLine1:xxx"
				+ ",district:pune,state:MH,pinCode:411057,emergencyContactNo:987654321},{addressId:2,addressLine1:yyy,district:delhi,state:Delhi,pinCode:110076,emergencyContactNo:123456789}]";
		JSONAssert.assertEquals(expected, result.getResponse().getContentAsString(), false);
	}

	@Test
	public void putAddress() throws Exception {
		String addressPut = "{\"addressLine1\":\"try1-try-try\",\"district\":\"shivaji\",\"state\":\"MH\",\"pinCode\":411057,\"emergencyContactNo\":101192}";
		Mockito.when(addressService.putAddress(Mockito.any(AddressModal.class))).thenReturn(Mockito.anyLong());
		RequestBuilder requestBuilder = MockMvcRequestBuilders.put("/address/add").accept(MediaType.APPLICATION_JSON)
				.content(addressPut).contentType(MediaType.APPLICATION_JSON);
		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		MockHttpServletResponse response = result.getResponse();
		assertEquals(HttpStatus.SC_OK, response.getStatus());

	}
	
	@Test
	public void getAddressFail() throws Exception {

		AddressModal modal = new AddressModal();
		Mockito.when(addressService.getAddress(Mockito.anyLong())).thenReturn(modal);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.get("/address/id/1").accept(MediaType.APPLICATION_JSON);
		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		String expected = "{}";
		JSONAssert.assertEquals(expected, result.getResponse().getContentAsString(), false);
	}

	@Test
	public void getAllAddressFail() throws Exception {

		List<AddressModal> mockList = new ArrayList<AddressModal>();
		
		Mockito.when(addressService.getAllAddress()).thenReturn(mockList);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.get("/address/all").accept(MediaType.APPLICATION_JSON);
		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		String expected = "[]";
		JSONAssert.assertEquals(expected, result.getResponse().getContentAsString(), false);
	}

	@Test
	public void putAddressFail() throws Exception {
		String addressPut = "{}";
		Mockito.when(addressService.putAddress(Mockito.any(AddressModal.class))).thenReturn(0l);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.put("/address/add").accept(MediaType.APPLICATION_JSON)
				.content(addressPut).contentType(MediaType.APPLICATION_JSON);
		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		String expected = "0";
		JSONAssert.assertEquals(expected,result.getResponse().getContentAsString(),false);

	}

}
