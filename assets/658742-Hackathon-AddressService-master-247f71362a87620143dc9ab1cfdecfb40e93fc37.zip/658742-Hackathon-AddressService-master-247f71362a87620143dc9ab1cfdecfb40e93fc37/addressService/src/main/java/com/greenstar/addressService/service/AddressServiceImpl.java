package com.greenstar.addressService.service;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.greenstar.addressService.entity.AddressEntity;
import com.greenstar.addressService.modal.AddressModal;
import com.greenstar.addressService.repository.AddressRepository;

@Service
public class AddressServiceImpl implements AddressService{

	@Autowired(required = true)
	private AddressRepository addressRepository;
	
	@Override
	@Transactional(rollbackOn = Exception.class)
	public AddressModal getAddress(long id) throws Exception {
		
		AddressEntity data = null;
		AddressModal modalObject=null;
		try {
		data = addressRepository.getOne(id);
		modalObject = new AddressModal();
		BeanUtils.copyProperties(data, modalObject);
		}
		catch(Exception e) {
			throw e;
		}
		return modalObject;
		
	}

	@Override
	@Transactional(rollbackOn = Exception.class)
	public long putAddress(AddressModal addressModal) throws Exception {
		AddressEntity addressEntity = new AddressEntity();
		BeanUtils.copyProperties(addressModal, addressEntity);
		System.out.println(addressEntity.toString());
		long insert = 0;
		try {
			addressEntity=addressRepository.saveAndFlush(addressEntity);
			insert = addressEntity.getAddressId();
		} catch (Exception e) {
			throw e;
		}
		return insert;
	}

	@Override
	@Transactional(rollbackOn = Exception.class)
	public List<AddressModal> getAllAddress() throws Exception {
		
		List<AddressModal> dataList = new ArrayList<>();
		AddressModal dataFinal=null;
		try {
			List<AddressEntity> data = addressRepository.findAll();
			for (AddressEntity d : data) {
				dataFinal=new AddressModal();
				dataFinal.setAddressId(d.getAddressId());
				dataFinal.setAddressLine1(d.getAddressLine1());
				dataFinal.setDistrict(d.getDistrict());
				dataFinal.setEmergencyContactNo(d.getEmergencyContactNo());
				dataFinal.setPinCode(d.getPinCode());
				dataFinal.setState(d.getState());
				dataList.add(dataFinal);
				
			}
		} catch (Exception e) {
			throw e;
		}
		
		return dataList;
	}

	

}
