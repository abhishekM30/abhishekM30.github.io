package com.greenstar.addressService.service;

import java.util.List;

import com.greenstar.addressService.entity.AddressEntity;
import com.greenstar.addressService.modal.AddressModal;

public interface AddressService {
	public AddressModal getAddress(long id)  throws Exception;
	public List<AddressModal> getAllAddress()  throws Exception;
	public long putAddress(AddressModal addressModal)  throws Exception;
	
}
