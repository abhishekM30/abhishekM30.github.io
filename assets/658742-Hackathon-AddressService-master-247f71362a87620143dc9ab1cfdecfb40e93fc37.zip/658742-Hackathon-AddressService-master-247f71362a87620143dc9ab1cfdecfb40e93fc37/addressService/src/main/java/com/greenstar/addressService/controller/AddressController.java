package com.greenstar.addressService.controller;

import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.greenstar.addressService.entity.AddressEntity;
import com.greenstar.addressService.modal.AddressModal;
import com.greenstar.addressService.service.AddressService;

@RestController
public class AddressController {

	@Autowired
	private AddressService addressService;

	@GetMapping("/address/id/{id}")
	public AddressModal getAddress(@PathVariable long id) {
		AddressModal response = null;
		try {
			response = addressService.getAddress(id);
		} catch (Exception e) {
			e.printStackTrace(System.err);
		}

		return response;
	}

	@PutMapping("/address/add")
	public long putAddress(@RequestBody AddressModal addressModal) {
		long response = 0;
		try {
			response = addressService.putAddress(addressModal);
		} catch (Exception e) {
			e.printStackTrace(System.err);
		}
		return response;
	}

	@GetMapping("/address/all")
	public List<AddressModal> getAllAddress() {
		List<AddressModal> response = null;
		try {
			response = addressService.getAllAddress();
		} catch (Exception e) {
			e.printStackTrace(System.err);
		}
		return response;
	}

}
