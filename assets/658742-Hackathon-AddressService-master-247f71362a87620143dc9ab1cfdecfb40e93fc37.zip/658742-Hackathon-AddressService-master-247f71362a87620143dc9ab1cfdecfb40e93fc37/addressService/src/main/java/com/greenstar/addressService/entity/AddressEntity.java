package com.greenstar.addressService.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "ADDRESS")
public class AddressEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "address_id")
	private long addressId;

	@Column(name = "address_line1")
	private String addressLine1;

	@Column(name = "district")
	private String district;

	@Column(name = "state")
	private String state;

	@Column(name = "pincode")
	private int pinCode;

	@Column(name = "emergency_contact_no")
	private int emergencyContactNo;

	public AddressEntity() {

	}

	public AddressEntity(long addressId, String addressLine1, String district, String state, int pinCode,
			int emergencyContactNo) {
		super();
		this.addressId = addressId;
		this.addressLine1 = addressLine1;
		this.district = district;
		this.state = state;
		this.pinCode = pinCode;
		this.emergencyContactNo = emergencyContactNo;
	}

	public long getAddressId() {
		return addressId;
	}

	public void setAddressId(long addressId) {
		this.addressId = addressId;
	}

	public String getAddressLine1() {
		return addressLine1;
	}

	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}

	public String getDistrict() {
		return district;
	}

	public void setDistrict(String district) {
		this.district = district;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public int getPinCode() {
		return pinCode;
	}

	public void setPinCode(int pinCode) {
		this.pinCode = pinCode;
	}

	public int getEmergencyContactNo() {
		return emergencyContactNo;
	}

	public void setEmergencyContactNo(int emergencyContactNo) {
		this.emergencyContactNo = emergencyContactNo;
	}

}
