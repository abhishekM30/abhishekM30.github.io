package com.greenstar.addressService.modal;

public class AddressModal {

	private long addressId;

	private String addressLine1;

	private String district;

	private String state;

	private int pinCode;

	private int emergencyContactNo;

	public AddressModal() {

	}

	public AddressModal(int addressId, String addressLine1, String district, String state, int pinCode,
			int emergencyContactNo) {
		super();
		this.addressId = addressId;
		this.addressLine1 = addressLine1;
		this.district = district;
		this.state = state;
		this.pinCode = pinCode;
		this.emergencyContactNo = emergencyContactNo;
	}

	public long getAddressId() {
		return addressId;
	}

	public void setAddressId(long addressId) {
		this.addressId = addressId;
	}

	public String getAddressLine1() {
		return addressLine1;
	}

	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}

	public String getDistrict() {
		return district;
	}

	public void setDistrict(String district) {
		this.district = district;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public int getPinCode() {
		return pinCode;
	}

	public void setPinCode(int pinCode) {
		this.pinCode = pinCode;
	}

	public int getEmergencyContactNo() {
		return emergencyContactNo;
	}

	public void setEmergencyContactNo(int emergencyContactNo) {
		this.emergencyContactNo = emergencyContactNo;
	}

	@Override
	public String toString() {
		return "AddressModal [addressId=" + addressId + ", addressLine1=" + addressLine1 + ", district=" + district
				+ ", state=" + state + ", pinCode=" + pinCode + ", emergencyContactNo=" + emergencyContactNo + "]";
	}

	
}
