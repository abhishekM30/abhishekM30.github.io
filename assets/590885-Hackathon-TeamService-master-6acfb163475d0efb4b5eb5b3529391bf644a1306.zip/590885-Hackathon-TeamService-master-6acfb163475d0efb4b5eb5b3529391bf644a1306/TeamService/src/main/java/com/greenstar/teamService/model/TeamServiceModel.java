package com.greenstar.teamService.model;

import java.util.Date;



public class TeamServiceModel {

	private long team_id;

	private String team_name;

	private Date team_creation_date;

	private String soft_delete;

	private long school_id;

	public TeamServiceModel() {
		
	}

	public TeamServiceModel(long team_id, String team_name, Date team_creation_date, String soft_delete, long school_id) {
		super();
		this.team_id = team_id;
		this.team_name = team_name;
		this.team_creation_date = team_creation_date;
		this.soft_delete = soft_delete;
		this.school_id = school_id;
	}

	public long getTeam_id() {
		return team_id;
	}

	public void setTeam_id(long team_id) {
		this.team_id = team_id;
	}

	public String getTeam_name() {
		return team_name;
	}

	public void setTeam_name(String team_name) {
		this.team_name = team_name;
	}

	public Date getTeam_creation_date() {
		return team_creation_date;
	}

	public void setTeam_creation_date(Date team_creation_date) {
		this.team_creation_date = team_creation_date;
	}

	public String getSoft_delete() {
		return soft_delete;
	}

	public void setSoft_delete(String soft_delete) {
		this.soft_delete = soft_delete;
	}

	public long getSchool_id() {
		return school_id;
	}

	public void setSchool_id(long school_id) {
		this.school_id = school_id;
	}
	
	
}
