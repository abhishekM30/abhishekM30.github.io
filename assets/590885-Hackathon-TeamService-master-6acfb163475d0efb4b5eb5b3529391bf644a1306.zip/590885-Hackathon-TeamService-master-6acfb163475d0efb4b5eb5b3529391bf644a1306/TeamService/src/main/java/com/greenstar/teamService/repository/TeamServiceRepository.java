package com.greenstar.teamService.repository;

import org.springframework.data.jpa.repository.JpaRepository;


import com.greenstar.teamService.entity.TeamServiceEntity;

public interface TeamServiceRepository extends JpaRepository<TeamServiceEntity, Long> {

}
