package com.greenstar.teamService.service;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.greenstar.teamService.entity.TeamServiceEntity;
import com.greenstar.teamService.model.TeamServiceModel;
import com.greenstar.teamService.repository.TeamServiceRepository;

@Service
public class TeamServiceImpl implements TeamService {

	@Autowired(required = true)
	private TeamServiceRepository teamServiceRepository;

	@Override
	@Transactional(rollbackOn = Exception.class)
	public TeamServiceModel getAddress(long id) {

		TeamServiceEntity data = null;
		TeamServiceModel modalObject = null;
		try {
			data = teamServiceRepository.getOne(id);
			modalObject = new TeamServiceModel();
			BeanUtils.copyProperties(data, modalObject);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return modalObject;

	}

	@Override
	@Transactional(rollbackOn = Exception.class)
	public long putAddress(TeamServiceEntity teamServiceEntity) {
		System.out.println(teamServiceEntity.toString());
		long insert = 0;
		try {
			//teamServiceEntity.setSchool_id(school_id); TODO : from schoolService
			teamServiceEntity= teamServiceRepository.saveAndFlush(teamServiceEntity);
			insert = teamServiceEntity.getTeam_id();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return insert;
	}

	@Override
	@Transactional(rollbackOn = Exception.class)
	public List<TeamServiceModel> getAllAddress() {

		List<TeamServiceModel> dataList = new ArrayList<TeamServiceModel>();
		TeamServiceModel dataFinal = null;
		try {
			List<TeamServiceEntity> data = teamServiceRepository.findAll();
			for (TeamServiceEntity d : data) {
				dataFinal = new TeamServiceModel();

				dataFinal.setTeam_id(d.getTeam_id());
				dataFinal.setTeam_name(d.getTeam_name());
				dataFinal.setTeam_creation_date(d.getTeam_creation_date());
				dataFinal.setSoft_delete(d.getSoft_delete());
				dataFinal.setSchool_id(d.getSchool_id());

				dataList.add(dataFinal);

			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return dataList;
	}

}
