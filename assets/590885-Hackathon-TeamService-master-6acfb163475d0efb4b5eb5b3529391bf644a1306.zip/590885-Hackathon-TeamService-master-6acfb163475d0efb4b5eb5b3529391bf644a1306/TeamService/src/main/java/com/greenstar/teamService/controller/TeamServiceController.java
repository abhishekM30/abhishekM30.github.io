package com.greenstar.teamService.controller;

import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.greenstar.teamService.entity.TeamServiceEntity;
import com.greenstar.teamService.model.TeamServiceModel;
import com.greenstar.teamService.service.TeamService;

@RestController
public class TeamServiceController {

	@Autowired
	private TeamService teamService;
	
	@GetMapping("/team/id/{id}")
	public TeamServiceModel getAddress(@PathVariable long id) {
		TeamServiceModel response = null;
		try {
			response = teamService.getAddress(id);
		} catch (Exception e) {
			e.printStackTrace();
		}

		return response;
	}

	@PutMapping("/team/add")
	public long putAddress(@RequestBody TeamServiceModel teamServiceModel) {
		long response = 0;
		TeamServiceEntity teamServiceEntity=new TeamServiceEntity();
		try {
			BeanUtils.copyProperties(teamServiceModel, teamServiceEntity);
			response = teamService.putAddress(teamServiceEntity);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return response;
	}

	@GetMapping("/team/all")
	public List<TeamServiceModel> getAllAddress() {
		List<TeamServiceModel> response = null;
		try {
			response = teamService.getAllAddress();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return response;
	}
}
