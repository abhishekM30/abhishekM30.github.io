package com.greenstar.teamService.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "TEAM_DETAIL")
public class TeamServiceEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "TEAM_ID")
	private long team_id;

	@Column(name = "TEAM_NAME")
	private String team_name;

	@Column(name = "TEAM_CREATION_DATE")
	private Date team_creation_date;

	@Column(name = "SOFT_DELETE")
	private String soft_delete;

	@Column(name = "SCHOOL_ID")
	private long school_id;

	public TeamServiceEntity() {

	}
	
	

	@Override
	public String toString() {
		return "TeamServiceEntity [team_id=" + team_id + ", team_name=" + team_name + ", team_creation_date="
				+ team_creation_date + ", soft_delete=" + soft_delete + ", school_id=" + school_id + "]";
	}



	public TeamServiceEntity(long team_id, String team_name, Date team_creation_date, String soft_delete,
			long school_id) {
		super();
		this.team_id = team_id;
		this.team_name = team_name;
		this.team_creation_date = team_creation_date;
		this.soft_delete = soft_delete;
		this.school_id = school_id;
	}

	public long getTeam_id() {
		return team_id;
	}

	public void setTeam_id(long team_id) {
		this.team_id = team_id;
	}

	public String getTeam_name() {
		return team_name;
	}

	public void setTeam_name(String team_name) {
		this.team_name = team_name;
	}

	public Date getTeam_creation_date() {
		return team_creation_date;
	}

	public void setTeam_creation_date(Date team_creation_date) {
		this.team_creation_date = team_creation_date;
	}

	public String getSoft_delete() {
		return soft_delete;
	}

	public void setSoft_delete(String soft_delete) {
		this.soft_delete = soft_delete;
	}

	public long getSchool_id() {
		return school_id;
	}

	public void setSchool_id(long school_id) {
		this.school_id = school_id;
	}

	
	
}
