package com.greenstar.teamService.service;

import java.util.List;

import com.greenstar.teamService.entity.TeamServiceEntity;
import com.greenstar.teamService.model.TeamServiceModel;


public interface TeamService {

	public TeamServiceModel getAddress(long id);

	public long putAddress(TeamServiceEntity teamServiceEntity);

	public List<TeamServiceModel> getAllAddress();

}
