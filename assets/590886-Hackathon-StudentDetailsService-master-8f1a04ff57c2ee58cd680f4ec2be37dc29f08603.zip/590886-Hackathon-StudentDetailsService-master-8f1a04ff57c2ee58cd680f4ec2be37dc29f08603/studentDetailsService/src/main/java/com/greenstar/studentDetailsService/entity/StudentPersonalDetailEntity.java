package com.greenstar.studentDetailsService.entity;

import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name="student_personal_details")
public class StudentPersonalDetailEntity {

	@Id
	@Column(name="STUDENT_DETAIL_ID")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long studentDetailId;

	@Column(name="ADDRESS_ID")
	private long addressId;

	private int age;

	@Column(name="BLOOD_TYPE")
	private String bloodType;

	@Temporal(TemporalType.DATE)
	@Column(name="DOB")
	private Date dob;

	@Temporal(TemporalType.DATE)
	@Column(name="DOJ")
	private Date doj;

	@Column(name="FIRST_NAME")
	private String firstName;

	@Column(name="LAST_NAME")
	private String lastName;

	@Column(name="MIDDLE_NAME")
	private String middleName;

	//bi-directional many-to-one association to StudentDetail
	@OneToMany(mappedBy="studentPersonalDetail")
	private List<StudentDetailEntity> studentDetails;

	public StudentPersonalDetailEntity() {
	}

	public long getStudentDetailId() {
		return this.studentDetailId;
	}

	public void setStudentDetailId(long studentDetailId) {
		this.studentDetailId = studentDetailId;
	}

	public long getAddressId() {
		return this.addressId;
	}

	public void setAddressId(long addressId) {
		this.addressId = addressId;
	}

	public int getAge() {
		return this.age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getBloodType() {
		return this.bloodType;
	}

	public void setBloodType(String bloodType) {
		this.bloodType = bloodType;
	}

	public Date getDob() {
		return this.dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	public Date getDoj() {
		return this.doj;
	}

	public void setDoj(Date doj) {
		this.doj = doj;
	}

	public String getFirstName() {
		return this.firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return this.lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getMiddleName() {
		return this.middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public List<StudentDetailEntity> getStudentDetails() {
		return this.studentDetails;
	}

	public void setStudentDetails(List<StudentDetailEntity> studentDetails) {
		this.studentDetails = studentDetails;
	}
	



	public StudentDetailEntity addStudentDetail(StudentDetailEntity studentDetail) {
		getStudentDetails().add(studentDetail);
		studentDetail.setStudentPersonalDetail(this);

		return studentDetail;
	}

	public StudentDetailEntity removeStudentDetail(StudentDetailEntity studentDetail) {
		getStudentDetails().remove(studentDetail);
		studentDetail.setStudentPersonalDetail(null);

		return studentDetail;
	}
	
	

}
