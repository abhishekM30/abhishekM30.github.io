package com.greenstar.studentDetailsService.service;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.greenstar.studentDetailsService.entity.StudentDetailEntity;
import com.greenstar.studentDetailsService.entity.StudentPersonalDetailEntity;
import com.greenstar.studentDetailsService.modal.StudentDetailModel;
import com.greenstar.studentDetailsService.modal.StudentPersonalDetailModal;
import com.greenstar.studentDetailsService.repository.StudentDetailRepository;
import com.greenstar.studentDetailsService.repository.StudentPersonalDetailRepository;

@Service
public class StudentDetailServiceImpl implements StudentDetailService {

	@Autowired
	StudentDetailRepository studentDetailRepository;

	@Autowired
	StudentPersonalDetailRepository studentPersonalDetailRepository;

	@Autowired
	AddressService addressService;

	@Override
	@Transactional(rollbackOn = Exception.class)
	public StudentDetailModel getStudentById(long id) {
		StudentDetailEntity studentResponse = null;

		StudentDetailModel studentModal = new StudentDetailModel();
		StudentPersonalDetailModal studentPersonalModal = new StudentPersonalDetailModal();
		try {
			studentResponse = studentDetailRepository.getOne(id);
			
			BeanUtils.copyProperties(studentResponse.getStudentPersonalDetail(), studentPersonalModal);
			BeanUtils.copyProperties(studentResponse, studentModal);

			studentModal.setAddressModal(addressService.getAddress(studentPersonalModal.getAddressId()));
			studentModal.setStudentPersonalDetailModal(studentPersonalModal);
			
		} catch (Exception e) {
			throw e;
		}

		return studentModal;
	}

	@Override
	@Transactional(rollbackOn = Exception.class)
	public long putStudent(StudentDetailModel studentDetailModel) {
		long response = 0;

		StudentDetailEntity studentDetailEntity = null;
		StudentPersonalDetailEntity personalDetailEntity = null;

		try {
			long addressId = 0l;
			personalDetailEntity = new StudentPersonalDetailEntity();
			studentDetailEntity = new StudentDetailEntity();
			BeanUtils.copyProperties(studentDetailModel.getStudentPersonalDetailModal(), personalDetailEntity);
			BeanUtils.copyProperties(studentDetailModel, studentDetailEntity);

			addressId = addressService.putAddress(studentDetailModel.getAddressModal());

			personalDetailEntity.setAddressId(addressId);
			personalDetailEntity = studentPersonalDetailRepository.save(personalDetailEntity);

			// studentDetailEntity.setClassId(1L); // TODO : From classDetailsService
			// studentDetailEntity.setTeamId(1L); // TODO : from teamDetailsService
			studentDetailEntity.setStudentPersonalDetail(personalDetailEntity);
			studentDetailEntity = studentDetailRepository.save(studentDetailEntity);

			response = studentDetailEntity.getStudentId();

		} catch (Exception e) {
			throw e;
		}

		return response;
	}

	@Override
	public List<StudentDetailModel> getStudentByClassId(long classid) {
		List<StudentDetailModel> modalList=new ArrayList<StudentDetailModel>();
		List<StudentDetailEntity> responseList = new ArrayList<StudentDetailEntity>();
		responseList=studentDetailRepository.findByClassId(classid);
		for(StudentDetailEntity element:responseList) {
			StudentDetailModel modal =new StudentDetailModel();
			StudentPersonalDetailModal studentPersonalModal = new StudentPersonalDetailModal();
			BeanUtils.copyProperties(element, modal);
			BeanUtils.copyProperties(element.getStudentPersonalDetail(), studentPersonalModal);
			

			modal.setAddressModal(addressService.getAddress(studentPersonalModal.getAddressId()));
			modal.setStudentPersonalDetailModal(studentPersonalModal);
			modalList.add(modal);
		}
		
		
		
		return modalList;
	}

}
