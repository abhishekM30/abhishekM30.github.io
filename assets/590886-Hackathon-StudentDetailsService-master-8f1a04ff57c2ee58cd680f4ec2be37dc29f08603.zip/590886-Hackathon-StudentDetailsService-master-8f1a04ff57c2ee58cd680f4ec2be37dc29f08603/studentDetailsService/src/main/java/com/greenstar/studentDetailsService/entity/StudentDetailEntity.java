package com.greenstar.studentDetailsService.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "student_details")
public class StudentDetailEntity {

	@Id
	@Column(name = "STUDENT_ID")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long studentId;

	@Column(name = "CLASS_ID")
	private long classId;

	@Column(name = "LAST_UPDATED_BY")
	private String lastUpdatedBy;

	@Temporal(TemporalType.DATE)
	@Column(name = "LAST_UPDATED_ON")
	private Date lastUpdatedOn;

	@Column(name = "SOFT_DELETE")
	private String softDelete;

	@Temporal(TemporalType.DATE)
	@Column(name = "SOFT_DELETE_DATE")
	private Date softDeleteDate;

	@Column(name = "STUDENT_OLD_IDS")
	private String studentOldIds;

	@Column(name = "TEAM_ID")
	private long teamId;

	// bi-directional many-to-one association to StudentPersonalDetail
	@ManyToOne
	@JoinColumn(name = "STUDENT_DETAIL_ID")
	private StudentPersonalDetailEntity studentPersonalDetail;

	public StudentDetailEntity() {
	}

	public long getStudentId() {
		return this.studentId;
	}

	public void setStudentId(long studentId) {
		this.studentId = studentId;
	}

	public long getClassId() {
		return this.classId;
	}

	public void setClassId(long classId) {
		this.classId = classId;
	}

	public String getLastUpdatedBy() {
		return this.lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public Date getLastUpdatedOn() {
		return this.lastUpdatedOn;
	}

	public void setLastUpdatedOn(Date lastUpdatedOn) {
		this.lastUpdatedOn = lastUpdatedOn;
	}

	public String getSoftDelete() {
		return this.softDelete;
	}

	public void setSoftDelete(String softDelete) {
		this.softDelete = softDelete;
	}

	public Date getSoftDeleteDate() {
		return this.softDeleteDate;
	}

	public void setSoftDeleteDate(Date softDeleteDate) {
		this.softDeleteDate = softDeleteDate;
	}

	public String getStudentOldIds() {
		return this.studentOldIds;
	}

	public void setStudentOldIds(String studentOldIds) {
		this.studentOldIds = studentOldIds;
	}

	public long getTeamId() {
		return this.teamId;
	}

	public void setTeamId(long teamId) {
		this.teamId = teamId;
	}

	public StudentPersonalDetailEntity getStudentPersonalDetail() {
		return this.studentPersonalDetail;
	}

	public void setStudentPersonalDetail(StudentPersonalDetailEntity studentPersonalDetail) {
		this.studentPersonalDetail = studentPersonalDetail;
	}

}
