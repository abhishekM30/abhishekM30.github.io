package com.greenstar.studentDetailsService.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.greenstar.studentDetailsService.modal.StudentDetailModel;
import com.greenstar.studentDetailsService.service.StudentDetailService;

@RestController
public class StudentController {

	@Autowired
	private StudentDetailService studentDetailService;

	@GetMapping("/student/id/{id}")
	public StudentDetailModel getStudent(@PathVariable long id) {

		StudentDetailModel modal = null;

		try {
			modal = studentDetailService.getStudentById(id);
		} catch (Exception e) {
			e.printStackTrace(System.err);
		}

		return modal;
	}

	@PutMapping("/student/add")
	public long putStudent(@RequestBody StudentDetailModel studentDetailModel ) {

		long modal = 0;

		try {
			modal = studentDetailService.putStudent(studentDetailModel);
		} catch (Exception e) {
			e.printStackTrace(System.err);
		}

		return modal;
	}
	
	@GetMapping("/student/class/id/{classid}")
	public List<StudentDetailModel> getStudentByClassId(@PathVariable long classid) {

		List<StudentDetailModel> modal = null;

		try {
			modal = studentDetailService.getStudentByClassId(classid);
		} catch (Exception e) {
			e.printStackTrace(System.err);
		}

		return modal;
	}
	
	

}
