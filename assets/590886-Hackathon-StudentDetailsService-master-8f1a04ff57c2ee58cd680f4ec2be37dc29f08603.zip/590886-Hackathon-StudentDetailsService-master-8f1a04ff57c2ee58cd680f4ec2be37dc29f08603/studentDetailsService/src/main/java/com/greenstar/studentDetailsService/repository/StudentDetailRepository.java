package com.greenstar.studentDetailsService.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.greenstar.studentDetailsService.entity.StudentDetailEntity;

public interface StudentDetailRepository extends JpaRepository<StudentDetailEntity,Long>{

	List<StudentDetailEntity> findByClassId(long classid);

}
