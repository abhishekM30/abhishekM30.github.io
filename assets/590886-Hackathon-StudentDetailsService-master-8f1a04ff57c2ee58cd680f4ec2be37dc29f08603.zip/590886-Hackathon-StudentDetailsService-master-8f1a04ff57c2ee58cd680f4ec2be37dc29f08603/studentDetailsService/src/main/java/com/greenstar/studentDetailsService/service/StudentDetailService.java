package com.greenstar.studentDetailsService.service;

import java.util.List;

import com.greenstar.studentDetailsService.modal.StudentDetailModel;

public interface StudentDetailService {

	StudentDetailModel getStudentById(long id);

	long putStudent(StudentDetailModel studentDetailModel);

	List<StudentDetailModel> getStudentByClassId(long classid);

}
