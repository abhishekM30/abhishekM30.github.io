package com.greenstar.studentDetailsService.modal;

import java.util.Date;

public class StudentDetailModel {

	private long studentId;
	private long classId;
	private String lastUpdatedBy;
	private Date lastUpdatedOn;
	private String softDelete;
	private Date softDeleteDate;
	private String studentOldIds;
	private long teamId;
	private StudentPersonalDetailModal studentPersonalDetailModal;
	private AddressModal addressModal;
	
	
	public StudentDetailModel() {

	}
	public long getStudentId() {
		return studentId;
	}
	public void setStudentId(long studentId) {
		this.studentId = studentId;
	}
	public long getClassId() {
		return classId;
	}
	public void setClassId(long classId) {
		this.classId = classId;
	}
	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}
	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}
	public Date getLastUpdatedOn() {
		return lastUpdatedOn;
	}
	public void setLastUpdatedOn(Date lastUpdatedOn) {
		this.lastUpdatedOn = lastUpdatedOn;
	}
	public String getSoftDelete() {
		return softDelete;
	}
	public void setSoftDelete(String softDelete) {
		this.softDelete = softDelete;
	}
	public Date getSoftDeleteDate() {
		return softDeleteDate;
	}
	public void setSoftDeleteDate(Date softDeleteDate) {
		this.softDeleteDate = softDeleteDate;
	}
	public String getStudentOldIds() {
		return studentOldIds;
	}
	public void setStudentOldIds(String studentOldIds) {
		this.studentOldIds = studentOldIds;
	}
	public long getTeamId() {
		return teamId;
	}
	public void setTeamId(long teamId) {
		this.teamId = teamId;
	}
	public StudentPersonalDetailModal getStudentPersonalDetailModal() {
		return studentPersonalDetailModal;
	}
	public void setStudentPersonalDetailModal(StudentPersonalDetailModal studentPersonalDetailModal) {
		this.studentPersonalDetailModal = studentPersonalDetailModal;
	}
	public AddressModal getAddressModal() {
		return addressModal;
	}
	public void setAddressModal(AddressModal addressModal) {
		this.addressModal = addressModal;
	}
	
	
	
}
