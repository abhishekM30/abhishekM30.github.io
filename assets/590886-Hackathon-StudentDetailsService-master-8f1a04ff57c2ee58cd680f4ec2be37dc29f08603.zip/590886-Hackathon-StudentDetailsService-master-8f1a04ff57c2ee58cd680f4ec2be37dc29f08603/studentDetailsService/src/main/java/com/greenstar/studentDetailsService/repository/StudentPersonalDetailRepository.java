package com.greenstar.studentDetailsService.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.greenstar.studentDetailsService.entity.StudentPersonalDetailEntity;

public interface StudentPersonalDetailRepository extends JpaRepository<StudentPersonalDetailEntity, Long>{

}
