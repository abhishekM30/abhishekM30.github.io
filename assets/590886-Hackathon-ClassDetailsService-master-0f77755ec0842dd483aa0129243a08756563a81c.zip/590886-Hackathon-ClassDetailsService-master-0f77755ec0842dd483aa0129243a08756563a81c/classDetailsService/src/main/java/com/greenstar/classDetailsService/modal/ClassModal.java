package com.greenstar.classDetailsService.modal;

import java.util.ArrayList;
import java.util.Date;

public class ClassModal {
	
	private long classId;

	private String classIncharge;

	private ArrayList<String> classNameSection;
	
	private int className;

	private String classSection;

	private Date formationDate;

	private long schoolId;

	private String softDelete;




	public long getClassId() {
		return classId;
	}

	public void setClassId(long classId) {
		this.classId = classId;
	}

	public ArrayList<String> getClassNameSection() {
		return classNameSection;
	}

	public void setClassNameSection(ArrayList<String> classNameSection) {
		this.classNameSection = classNameSection;
	}

	public String getClassIncharge() {
		return classIncharge;
	}

	public void setClassIncharge(String classIncharge) {
		this.classIncharge = classIncharge;
	}

	public int getClassName() {
		return className;
	}

	public void setClassName(int className) {
		this.className = className;
	}

	public String getClassSection() {
		return classSection;
	}

	public void setClassSection(String classSection) {
		this.classSection = classSection;
	}

	public Date getFormationDate() {
		return formationDate;
	}

	public void setFormationDate(Date formationDate) {
		this.formationDate = formationDate;
	}

	public long getSchoolId() {
		return schoolId;
	}

	public void setSchoolId(long schoolId) {
		this.schoolId = schoolId;
	}

	public String getSoftDelete() {
		return softDelete;
	}

	public void setSoftDelete(String softDelete) {
		this.softDelete = softDelete;
	}

	

	public ClassModal() {
	}

	public ClassModal(long classId, String classIncharge, ArrayList<String> classNameSection, int className,
			String classSection, Date formationDate, long schoolId, String softDelete) {
		super();
		this.classId = classId;
		this.classIncharge = classIncharge;
		this.classNameSection = classNameSection;
		this.className = className;
		this.classSection = classSection;
		this.formationDate = formationDate;
		this.schoolId = schoolId;
		this.softDelete = softDelete;
	}

	@Override
	public String toString() {
		return "ClassModal [classId=" + classId + ", classIncharge=" + classIncharge + ", classNameSection="
				+ classNameSection + ", className=" + className + ", classSection=" + classSection + ", formationDate="
				+ formationDate + ", schoolId=" + schoolId + ", softDelete=" + softDelete + "]";
	}
	
	
	

}
