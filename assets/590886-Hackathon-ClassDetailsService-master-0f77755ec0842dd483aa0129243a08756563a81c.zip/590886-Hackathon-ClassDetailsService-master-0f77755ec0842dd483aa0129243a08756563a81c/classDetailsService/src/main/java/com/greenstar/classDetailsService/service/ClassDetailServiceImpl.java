package com.greenstar.classDetailsService.service;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.greenstar.classDetailsService.entity.ClassDetail;
import com.greenstar.classDetailsService.modal.ClassIdParam;
import com.greenstar.classDetailsService.modal.ClassModal;
import com.greenstar.classDetailsService.repository.ClassDetailRepository;

@Service
public class ClassDetailServiceImpl implements ClassDetailService {

	@Autowired
	ClassDetailRepository classDetailRepository;

	@Override
	@Transactional(rollbackOn = Exception.class)
	public ClassModal getClassDetailById(long id) {
		ClassDetail response = null;
		ClassModal classModal = new ClassModal();
		try {

			response = classDetailRepository.getOne(id);
			BeanUtils.copyProperties(response, classModal);
		} catch (Exception e) {
			throw e;
		}

		return classModal;
	}

	@Override
	@Transactional(rollbackOn = Exception.class)
	public List<ClassModal> getClassBySchoolId(long schoolId) {
		List<ClassModal> classModals = null;
		try {
			classModals = new ArrayList<>();
			List<ClassDetail> classDetails = classDetailRepository.findBySchoolId(schoolId);
			for(ClassDetail classDetail : classDetails){
				ClassModal classModal = new ClassModal();
				BeanUtils.copyProperties(classDetail, classModal);
				classModals.add(classModal);
			}
		} catch (Exception e) {
			throw e;
		}

		return classModals;
	}

	@Override
	@Transactional(rollbackOn = Exception.class)
	public List<ClassModal> getClassAll() {
		List<ClassDetail> entity = null;
		ClassModal modal = new ClassModal();
		List<ClassModal> response = new ArrayList<>();
		try {
			entity = classDetailRepository.findAll();
			for (ClassDetail data : entity) {
				BeanUtils.copyProperties(data, modal);
				response.add(modal);
			}

		} catch (Exception e) {
			throw e;
		}

		return response;
	}

	@Override
	@Transactional(rollbackOn = Exception.class)
	public List<ClassIdParam> putClassAdd(ClassModal classModal) {
		ClassDetail response = null;
		List<ClassIdParam> modalList = new ArrayList<>();
		
		try {

			for (String className : classModal.getClassNameSection()) {
				ClassIdParam modal = new ClassIdParam();
				ClassDetail classDetailEntity = new ClassDetail();
				String classNameAarry[] = className.split("-");
				classModal.setClassName(Integer.parseInt(classNameAarry[0]));
				classModal.setClassSection(classNameAarry[1]);
				BeanUtils.copyProperties(classModal, classDetailEntity);
				response = classDetailRepository.saveAndFlush(classDetailEntity);
				modal.setClassId(response.getClassId());
				modal.setClassName(className);
				modalList.add(modal);
			}

		} catch (Exception e) {
			throw e;
		}
		return modalList;
	}

}
