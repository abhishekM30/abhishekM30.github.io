package com.greenstar.classDetailsService.modal;

public class ClassIdParam {

	private long classId;
	private String className;
	
	
	@Override
	public String toString() {
		return "ClassIdParam [classId=" + classId + ", className=" + className + "]";
	}
	public long getClassId() {
		return classId;
	}
	public void setClassId(long classId) {
		this.classId = classId;
	}
	public String getClassName() {
		return className;
	}
	public void setClassName(String className) {
		this.className = className;
	}
	
	
	
}
