package com.greenstar.classDetailsService.service;

import java.util.List;

import com.greenstar.classDetailsService.modal.ClassIdParam;
import com.greenstar.classDetailsService.modal.ClassModal;

public interface ClassDetailService {

	public ClassModal getClassDetailById(long id);

	public List<ClassModal> getClassBySchoolId(long schoolId);

	public List<ClassModal> getClassAll();

	public List<ClassIdParam> putClassAdd(ClassModal classModal);

}
