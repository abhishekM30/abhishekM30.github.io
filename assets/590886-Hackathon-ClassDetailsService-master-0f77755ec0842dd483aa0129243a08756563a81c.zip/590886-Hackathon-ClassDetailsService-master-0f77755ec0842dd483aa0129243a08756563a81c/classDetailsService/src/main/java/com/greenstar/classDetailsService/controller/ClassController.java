package com.greenstar.classDetailsService.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.greenstar.classDetailsService.modal.ClassIdParam;
import com.greenstar.classDetailsService.modal.ClassModal;
import com.greenstar.classDetailsService.service.ClassDetailService;

@RestController
public class ClassController {

	@Autowired
	ClassDetailService classDetailService;

	@GetMapping("/class/id/{id}")
	public ClassModal getClassDetailById(@PathVariable long id) {
		ClassModal response = null;
		try {
			response = classDetailService.getClassDetailById(id);

		} catch (Exception e) {
			e.printStackTrace();
		}

		return response;
	}
	
	@GetMapping("/class/school/id/{schoolId}")
	public List<ClassModal> getClassBySchoolId(@PathVariable long schoolId) {
		List<ClassModal> response = null;
		try {
			response = classDetailService.getClassBySchoolId(schoolId);

		} catch (Exception e) {
			e.printStackTrace();
		}

		return response;
	}

	@GetMapping("/class/all")
	public List<ClassModal> getClassAll() {
		List<ClassModal> response = null;

		try {
			response = classDetailService.getClassAll();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return response;
	}

	@PutMapping("/class/add")
	public List<ClassIdParam> putClassAdd(@RequestBody ClassModal classModal) {
		List<ClassIdParam> response = new ArrayList<>();
		try {
			response = classDetailService.putClassAdd(classModal);
		} catch (Exception e) {
			e.printStackTrace();
		}

		return response;
	}

}
