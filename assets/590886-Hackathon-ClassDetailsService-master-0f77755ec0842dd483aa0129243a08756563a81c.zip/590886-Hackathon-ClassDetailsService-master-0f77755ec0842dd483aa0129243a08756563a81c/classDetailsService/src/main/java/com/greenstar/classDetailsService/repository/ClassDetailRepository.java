package com.greenstar.classDetailsService.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.greenstar.classDetailsService.entity.ClassDetail;

public interface ClassDetailRepository extends JpaRepository<ClassDetail, Long> {
	public List<ClassDetail> findBySchoolId(long schoolId);
}
