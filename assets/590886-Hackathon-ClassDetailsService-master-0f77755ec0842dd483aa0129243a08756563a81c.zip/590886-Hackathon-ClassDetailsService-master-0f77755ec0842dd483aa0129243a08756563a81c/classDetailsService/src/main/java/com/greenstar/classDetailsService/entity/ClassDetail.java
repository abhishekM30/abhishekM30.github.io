package com.greenstar.classDetailsService.entity;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;


/**
 * The persistent class for the class_detail database table.
 * 
 */
@Entity
@Table(name="class_detail")
public class ClassDetail implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="CLASS_ID")
	private long classId;

	@Column(name="CLASS_INCHARGE")
	private String classIncharge;

	@Column(name="CLASS_NAME")
	private int className;

	@Column(name="CLASS_SECTION")
	private String classSection;

	@Temporal(TemporalType.DATE)
	@Column(name="FORMATION_DATE")
	private Date formationDate;

	@Column(name="SCHOOL_ID")
	private long schoolId;

	@Column(name="SOFT_DELETE")
	private String softDelete;

	public ClassDetail() {
	}

	public long getClassId() {
		return this.classId;
	}

	public void setClassId(long classId) {
		this.classId = classId;
	}

	public String getClassIncharge() {
		return this.classIncharge;
	}

	public void setClassIncharge(String classIncharge) {
		this.classIncharge = classIncharge;
	}

	public int getClassName() {
		return this.className;
	}

	public void setClassName(int className) {
		this.className = className;
	}

	public String getClassSection() {
		return this.classSection;
	}

	public void setClassSection(String classSection) {
		this.classSection = classSection;
	}

	public Date getFormationDate() {
		return this.formationDate;
	}

	public void setFormationDate(Date formationDate) {
		this.formationDate = formationDate;
	}

	public long getSchoolId() {
		return this.schoolId;
	}

	public void setSchoolId(long schoolId) {
		this.schoolId = schoolId;
	}

	public String getSoftDelete() {
		return this.softDelete;
	}

	public void setSoftDelete(String softDelete) {
		this.softDelete = softDelete;
	}

	@Override
	public String toString() {
		return "ClassDetail [classId=" + classId + ", classIncharge=" + classIncharge + ", className=" + className
				+ ", classSection=" + classSection + ", formationDate=" + formationDate + ", schoolId=" + schoolId
				+ ", softDelete=" + softDelete + "]";
	}

	
}
