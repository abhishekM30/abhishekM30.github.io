package com.greenstar.classDetailsService.controller;

import static org.junit.Assert.assertEquals;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.http.HttpStatus;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.skyscreamer.jsonassert.JSONAssert;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.greenstar.classDetailsService.modal.ClassIdParam;
import com.greenstar.classDetailsService.modal.ClassModal;
import com.greenstar.classDetailsService.service.ClassDetailService;

@RunWith(SpringRunner.class)
@WebMvcTest(value = ClassController.class, secure = false)
public class ClassControllerTest {

	@Autowired
	private MockMvc mockMvc;

	@MockBean
	ClassDetailService classDetailService;

	@Test
	public void getClassDetailById() throws Exception {

		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		String dateString = sdf.format(new Date());
		Date date = sdf.parse(dateString);
		ClassModal modal = new ClassModal(1, "testInchagre", null, 6, "D", date, 1, "Y");
		Mockito.when(classDetailService.getClassDetailById(Mockito.anyLong())).thenReturn(modal);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.get("/class/id/1").accept(MediaType.APPLICATION_JSON);
		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		assertEquals(HttpStatus.SC_OK, result.getResponse().getStatus());
	}

	@Test
	public void getClassBySchoolId() throws Exception {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		String dateString = sdf.format(new Date());
		Date date = sdf.parse(dateString);
		List<ClassModal> modalList = new ArrayList<ClassModal>();
		ClassModal modal1 = new ClassModal(1, "testInchagre", null, 6, "D", date, 1, "Y");
		ClassModal modal2 = new ClassModal(2, "testInchagre", null, 7, "D", date, 2, "N");
		modalList.add(modal1);
		modalList.add(modal2);
		Mockito.when(classDetailService.getClassBySchoolId(Mockito.anyLong())).thenReturn(modalList);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.get("/class/school/id/1")
				.accept(MediaType.APPLICATION_JSON);
		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		assertEquals(HttpStatus.SC_OK, result.getResponse().getStatus());
	}

	@Test
	public void getClassAll() throws Exception {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		String dateString = sdf.format(new Date());
		Date date = sdf.parse(dateString);
		List<ClassModal> modalList = new ArrayList<ClassModal>();
		ClassModal modal1 = new ClassModal(1, "testInchagre", null, 6, "D", date, 1, "Y");
		ClassModal modal2 = new ClassModal(2, "testInchagre", null, 7, "D", date, 2, "N");
		modalList.add(modal1);
		modalList.add(modal2);
		Mockito.when(classDetailService.getClassBySchoolId(Mockito.anyLong())).thenReturn(modalList);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.get("/class/all").accept(MediaType.APPLICATION_JSON);
		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		assertEquals(HttpStatus.SC_OK, result.getResponse().getStatus());
	}

	@Test
	public void putClassAdd() throws Exception {
		String putClass = "{\"classIncharge\": \"HOLA4\",\"schoolId\":7,\"classNameSection\":"
				+ "[\"12-A\",\"12-B\",\"12-D\"], \"formationDate\": \"2019-01-01\",\"softDelete\":\"Y\"}";
		List<ClassIdParam> listIds = new ArrayList<ClassIdParam>();
		ClassIdParam classParamModel1 = new ClassIdParam();
		classParamModel1.setClassId(1);
		classParamModel1.setClassName("1");
		ClassIdParam classParamModel2 = new ClassIdParam();
		classParamModel2.setClassId(2);
		classParamModel2.setClassName("2");
		listIds.add(classParamModel1);
		listIds.add(classParamModel2);
		Mockito.when(classDetailService.putClassAdd(Mockito.any(ClassModal.class))).thenReturn(listIds);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.put("/class/add").accept(MediaType.APPLICATION_JSON)
				.content(putClass).contentType(MediaType.APPLICATION_JSON);
		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		MockHttpServletResponse response = result.getResponse();
		assertEquals(HttpStatus.SC_OK, response.getStatus());

	}

	@Test
	public void getClassDetailByIdFail() throws Exception {

		ClassModal modal = new ClassModal();
		Mockito.when(classDetailService.getClassDetailById(Mockito.anyLong())).thenReturn(modal);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.get("/class/id/1").accept(MediaType.APPLICATION_JSON);
		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		JSONAssert.assertEquals("{}", result.getResponse().getContentAsString(), false);
	}

	@Test
	public void getClassBySchoolIdFail() throws Exception {

		List<ClassModal> modalList = new ArrayList<ClassModal>();
		Mockito.when(classDetailService.getClassBySchoolId(Mockito.anyLong())).thenReturn(modalList);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.get("/class/school/id/1")
				.accept(MediaType.APPLICATION_JSON);
		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		JSONAssert.assertEquals("[]", result.getResponse().getContentAsString(), false);
	}

	@Test
	public void getClassAllFail() throws Exception {

		List<ClassModal> modalList = new ArrayList<ClassModal>();

		Mockito.when(classDetailService.getClassBySchoolId(Mockito.anyLong())).thenReturn(modalList);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.get("/class/all").accept(MediaType.APPLICATION_JSON);
		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		JSONAssert.assertEquals("[]", result.getResponse().getContentAsString(), false);
	}

	@Test
	public void putClassAddFail() throws Exception {
		String putClass = "{}";
				
		List<ClassIdParam> listIds = new ArrayList<ClassIdParam>();

		Mockito.when(classDetailService.putClassAdd(Mockito.any(ClassModal.class))).thenReturn(listIds);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.put("/class/add").accept(MediaType.APPLICATION_JSON)
				.content(putClass).contentType(MediaType.APPLICATION_JSON);
		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		JSONAssert.assertEquals("[]", result.getResponse().getContentAsString(), false);

	}



}
