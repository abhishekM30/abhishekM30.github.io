package com.greenstar.classDetailsService.service;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.skyscreamer.jsonassert.JSONAssert;
import org.springframework.beans.BeanUtils;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import com.greenstar.classDetailsService.entity.ClassDetail;
import com.greenstar.classDetailsService.modal.ClassModal;
import com.greenstar.classDetailsService.repository.ClassDetailRepository;

@RunWith(SpringRunner.class)
@WebMvcTest(value = ClassDetailServiceImpl.class, secure = false)
public class ClassDetailServiceTest {

	@MockBean
	private ClassDetailRepository classDetailRepository;

	@Test
	public void getClassDetailById() throws Exception {

		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		String dateString = sdf.format(new Date());
		Date date = sdf.parse(dateString);
		ClassDetail entity = new ClassDetail();
		entity.setClassId(1);
		entity.setClassIncharge("TestIncharge");
		entity.setClassName(1);
		entity.setClassSection("D");
		entity.setFormationDate(date);
		entity.setSchoolId(1);
		entity.setSoftDelete("Y");
		ClassModal modal = new ClassModal();
		BeanUtils.copyProperties(entity, modal);
		Mockito.when(classDetailRepository.getOne(1l)).thenReturn(entity);
		JSONAssert.assertEquals(modal.getClassIncharge(), entity.getClassIncharge(), false);

	}

	@Test
	public void getClassBySchoolId() throws Exception {

		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		String dateString = sdf.format(new Date());
		Date date = sdf.parse(dateString);
		List<ClassDetail> entityList = new ArrayList<ClassDetail>();

		ClassDetail entity = new ClassDetail();
		entity.setClassId(1);
		entity.setClassIncharge("TestIncharge");
		entity.setClassName(1);
		entity.setClassSection("D");
		entity.setFormationDate(date);
		entity.setSchoolId(1);
		entity.setSoftDelete("Y");

		entityList.add(entity);

		ClassModal modal = new ClassModal();
		BeanUtils.copyProperties(entity, modal);
		Mockito.when(classDetailRepository.findBySchoolId(1l)).thenReturn(entityList);

		JSONAssert.assertEquals("TestIncharge", entityList.get(0).getClassIncharge(), false);

	}

	@Test
	public void getClassAll() throws Exception {

		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		String dateString = sdf.format(new Date());
		Date date = sdf.parse(dateString);
		List<ClassDetail> entityList = new ArrayList<ClassDetail>();

		ClassDetail entity = new ClassDetail();
		entity.setClassId(1);
		entity.setClassIncharge("TestIncharge");
		entity.setClassName(1);
		entity.setClassSection("D");
		entity.setFormationDate(date);
		entity.setSchoolId(1);
		entity.setSoftDelete("Y");

		entityList.add(entity);

		ClassModal modal = new ClassModal();
		BeanUtils.copyProperties(entity, modal);
		Mockito.when(classDetailRepository.findAll()).thenReturn(entityList);

		JSONAssert.assertEquals("TestIncharge", entityList.get(0).getClassIncharge(), false);

	}

	@Test
	public void putClassAdd() throws Exception {

		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		String dateString = sdf.format(new Date());
		Date date = sdf.parse(dateString);

		ClassDetail entity = new ClassDetail();
		entity.setClassId(1);
		entity.setClassIncharge("TestIncharge");
		entity.setClassName(1);
		entity.setClassSection("D");
		entity.setFormationDate(date);
		entity.setSchoolId(1);
		entity.setSoftDelete("Y");

		ClassModal modal = new ClassModal();
		BeanUtils.copyProperties(entity, modal);
		Mockito.when(classDetailRepository.saveAndFlush(entity)).thenReturn(entity);

		JSONAssert.assertEquals("TestIncharge", entity.getClassIncharge(), false);

	}

}
