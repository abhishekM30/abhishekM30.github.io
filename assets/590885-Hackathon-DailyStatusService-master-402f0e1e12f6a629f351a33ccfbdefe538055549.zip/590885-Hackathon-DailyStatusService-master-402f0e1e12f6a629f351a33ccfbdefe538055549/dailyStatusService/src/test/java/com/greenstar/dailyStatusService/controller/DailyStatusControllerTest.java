package com.greenstar.dailyStatusService.controller;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import org.apache.http.HttpStatus;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.greenstar.dailyStatusService.modal.GetStatusModel;
import com.greenstar.dailyStatusService.service.DailyService;

@RunWith(SpringRunner.class)
@WebMvcTest(value = DailyStatusController.class, secure = false)
public class DailyStatusControllerTest {

	@Autowired
	private MockMvc mockMvc;

	@MockBean
	DailyService dailyService;

	@Test
	public void getStudentById() throws Exception {

		GetStatusModel modal = new GetStatusModel(29, new Date(), 1, 1, 29, 29, "Y");
		List<GetStatusModel> modalList = new ArrayList<GetStatusModel>();
		modalList.add(modal);
		Mockito.when(dailyService.getStatusById(Mockito.anyLong())).thenReturn(modalList);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.get("/dailystatus/student/1")
				.accept(MediaType.APPLICATION_JSON);
		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		assertEquals(HttpStatus.SC_OK, result.getResponse().getStatus());
	}

	@Test
	public void getStatusByStatus() throws Exception {

		GetStatusModel modal = new GetStatusModel(29, new Date(), 1, 1, 29, 29, "Y");
		List<GetStatusModel> modalList = new ArrayList<GetStatusModel>();
		modalList.add(modal);
		Mockito.when(dailyService.getStatusByStatusValue(Mockito.anyString())).thenReturn(modalList);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.get("/dailystatus/student/1")
				.accept(MediaType.APPLICATION_JSON);
		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		assertEquals(HttpStatus.SC_OK, result.getResponse().getStatus());
	}

	@SuppressWarnings("unchecked")
	@Test
	public void putStatus() throws Exception {
		String putContent = "{\"forDate\": \"2012-01-01\",\"Student\": "
				+ "{\"12\": [{\"parameterId\": 1,\"status_id\": 1},{\"parameterId\": 2,\"status_id\": 1}],"
				+ "\"123\": [{\"parameterId\": 1,\"status_id\": 1},{\"parameterId\": 2,\"status_id\": 1}]}}";
		Mockito.when(dailyService.AddStatus(Mockito.any(HashMap.class))).thenReturn(Mockito.anyLong());
		RequestBuilder requestBuilder = MockMvcRequestBuilders.put("/dailystatus/add")
				.accept(MediaType.APPLICATION_JSON).content(putContent).contentType(MediaType.APPLICATION_JSON);
		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		assertEquals(HttpStatus.SC_OK, result.getResponse().getStatus());
	}

}
