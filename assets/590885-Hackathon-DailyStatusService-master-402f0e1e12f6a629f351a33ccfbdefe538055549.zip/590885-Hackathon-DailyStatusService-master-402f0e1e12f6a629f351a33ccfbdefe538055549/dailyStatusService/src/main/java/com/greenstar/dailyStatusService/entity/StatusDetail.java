package com.greenstar.dailyStatusService.entity;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the status_detail database table.
 * 
 */
@Entity
@Table(name="status_detail")
public class StatusDetail implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="STATUS_ID")
	private long statusId;

	@Column(name="STATUS_VALUE")
	private String statusValue;

	//bi-directional one-to-one association to DailyStatus
/*	@OneToOne(mappedBy="statusDetail")
	private DailyStatus dailyStatus;*/

	public StatusDetail() {
	}

	public long getStatusId() {
		return this.statusId;
	}

	public void setStatusId(long statusId) {
		this.statusId = statusId;
	}

	public String getStatusValue() {
		return this.statusValue;
	}

	public void setStatusValue(String statusValue) {
		this.statusValue = statusValue;
	}

/*	public DailyStatus getDailyStatus() {
		return this.dailyStatus;
	}

	public void setDailyStatus(DailyStatus dailyStatus) {
		this.dailyStatus = dailyStatus;
	}*/

}