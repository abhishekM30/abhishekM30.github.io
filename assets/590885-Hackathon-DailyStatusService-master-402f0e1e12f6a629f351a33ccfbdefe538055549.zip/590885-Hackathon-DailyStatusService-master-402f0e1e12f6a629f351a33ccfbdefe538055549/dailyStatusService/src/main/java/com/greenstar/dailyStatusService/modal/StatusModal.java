package com.greenstar.dailyStatusService.modal;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class StatusModal {

	/*{
	{
	"forDate": "asdasD",
	"studentId": {
		"12": [{
				"parameterId": 1,
				"status_id": 1
			},
			{
				"parameterId": 2,
				"status_id": 1
			}
		],
		"123": [{
				"parameterId": 1,
				"status_id": 1
			},
			{
				"parameterId": 2,
				"status_id": 1
			}
		]
	}
}
*/
	
	private Date forDate;
	private HashMap<String, List<StudentParameterDetail>> Student;
	public Date getForDate() {
		return forDate;
	}
	public void setForDate(Date forDate) {
		this.forDate = forDate;
	}
	public Map<String, List<StudentParameterDetail>> getStudent() {
		return Student;
	}
	public void setStudent(HashMap<String, List<StudentParameterDetail>> student) {
		Student = student;
	}
	public StatusModal(Date forDate, HashMap<String, List<StudentParameterDetail>> student) {
		super();
		this.forDate = forDate;
		Student = student;
	}
	public StatusModal() {
	}
	@Override
	public String toString() {
		return "StatusModal [forDate=" + forDate + ", Student=" + Student + "]";
	}	
}
