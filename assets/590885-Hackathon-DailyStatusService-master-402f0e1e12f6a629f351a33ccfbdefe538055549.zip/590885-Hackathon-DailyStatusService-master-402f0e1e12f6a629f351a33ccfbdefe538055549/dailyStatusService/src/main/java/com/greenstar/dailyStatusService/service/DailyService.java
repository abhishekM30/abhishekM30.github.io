package com.greenstar.dailyStatusService.service;

import java.text.ParseException;
import java.util.HashMap;
import java.util.List;

import com.greenstar.dailyStatusService.modal.GetStatusModel;

public interface DailyService {

	long AddStatus(HashMap<Object, Object> statusModal) throws ParseException;

	//long getAllStatus();

	List<GetStatusModel> getStatusById(long studentId);

	List<GetStatusModel> getStatusByStatusValue(String statusValue);

}
