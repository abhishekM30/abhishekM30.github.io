package com.greenstar.dailyStatusService.modal;

import java.util.Date;

public class GetStatusModel {
	private long dailyStatusId;

	private Date forDate;

	private long parameterId;

	private long studentId;

	private long statusDetail;
	
	private long statusId;

	private String statusValue;

	public long getDailyStatusId() {
		return dailyStatusId;
	}

	public void setDailyStatusId(long dailyStatusId) {
		this.dailyStatusId = dailyStatusId;
	}

	public Date getForDate() {
		return forDate;
	}

	public void setForDate(Date forDate) {
		this.forDate = forDate;
	}

	public long getParameterId() {
		return parameterId;
	}

	public void setParameterId(long parameterId) {
		this.parameterId = parameterId;
	}

	public long getStudentId() {
		return studentId;
	}

	public void setStudentId(long studentId) {
		this.studentId = studentId;
	}

	public long getStatusDetail() {
		return statusDetail;
	}

	public void setStatusDetail(long statusDetail) {
		this.statusDetail = statusDetail;
	}

	public long getStatusId() {
		return statusId;
	}

	public void setStatusId(long statusId) {
		this.statusId = statusId;
	}

	public String getStatusValue() {
		return statusValue;
	}

	public void setStatusValue(String statusValue) {
		this.statusValue = statusValue;
	}

	public GetStatusModel(long dailyStatusId, Date forDate, long parameterId, long studentId, long statusDetail,
			long statusId, String statusValue) {
		super();
		this.dailyStatusId = dailyStatusId;
		this.forDate = forDate;
		this.parameterId = parameterId;
		this.studentId = studentId;
		this.statusDetail = statusDetail;
		this.statusId = statusId;
		this.statusValue = statusValue;
	}

	public GetStatusModel() {
	}

	@Override
	public String toString() {
		return "StatusByStatusIdModel [dailyStatusId=" + dailyStatusId + ", forDate=" + forDate + ", parameterId="
				+ parameterId + ", studentId=" + studentId + ", statusDetail=" + statusDetail + ", statusId=" + statusId
				+ ", statusValue=" + statusValue + "]";
	}
	
	
	
}
