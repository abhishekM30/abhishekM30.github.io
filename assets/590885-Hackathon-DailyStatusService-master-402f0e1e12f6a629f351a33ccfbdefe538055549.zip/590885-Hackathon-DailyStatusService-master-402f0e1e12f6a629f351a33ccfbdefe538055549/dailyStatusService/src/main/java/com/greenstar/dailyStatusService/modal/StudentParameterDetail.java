package com.greenstar.dailyStatusService.modal;

public class StudentParameterDetail {

	private long parameterId;
	private long statusId;

	public long getParameterId() {
		return parameterId;
	}

	public void setParameterId(long parameterId) {
		this.parameterId = parameterId;
	}

	public long getStatusId() {
		return statusId;
	}

	public void setStatusId(long statusId) {
		this.statusId = statusId;
	}

	@Override
	public String toString() {
		return "StudentDetail [parameterId=" + parameterId + ", statusId=" + statusId + "]";
	}

	public StudentParameterDetail() {
	}
}
