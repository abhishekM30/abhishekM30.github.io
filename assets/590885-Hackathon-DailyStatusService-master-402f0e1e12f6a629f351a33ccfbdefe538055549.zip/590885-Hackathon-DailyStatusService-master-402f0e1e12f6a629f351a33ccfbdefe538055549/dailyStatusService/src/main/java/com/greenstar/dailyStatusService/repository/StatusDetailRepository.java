package com.greenstar.dailyStatusService.repository;

import java.util.ArrayList;

import org.springframework.data.jpa.repository.JpaRepository;

import com.greenstar.dailyStatusService.entity.StatusDetail;

public interface StatusDetailRepository extends JpaRepository<StatusDetail, Long>{

	ArrayList<StatusDetail> findAllByStatusValue(String statusValue);

}
