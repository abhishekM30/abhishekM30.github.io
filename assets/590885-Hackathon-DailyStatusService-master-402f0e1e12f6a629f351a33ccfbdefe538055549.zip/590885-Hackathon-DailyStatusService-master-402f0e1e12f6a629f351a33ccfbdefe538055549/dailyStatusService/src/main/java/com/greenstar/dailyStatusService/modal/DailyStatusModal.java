package com.greenstar.dailyStatusService.modal;

import java.io.Serializable;
import java.util.Date;



public class DailyStatusModal implements Serializable {
	private static final long serialVersionUID = 1L;

	private Date forDate;
	private long parameterId;
	private long studentId;
	private StatusDetailModal statusDetail;

	public DailyStatusModal() {
	}

	public Date getForDate() {
		return this.forDate;
	}

	public void setForDate(Date forDate) {
		this.forDate = forDate;
	}

	public long getParameterId() {
		return this.parameterId;
	}

	public void setParameterId(long parameterId) {
		this.parameterId = parameterId;
	}

	public long getStudentId() {
		return this.studentId;
	}

	public void setStudentId(long studentId) {
		this.studentId = studentId;
	}

	public StatusDetailModal getStatusDetail() {
		return this.statusDetail;
	}

	public void setStatusDetail(StatusDetailModal statusDetail) {
		this.statusDetail = statusDetail;
	}

	@Override
	public String toString() {
		return "DailyStatusModal [forDate=" + forDate + ", parameterId=" + parameterId + ", studentId=" + studentId
				+ ", statusDetail=" + statusDetail + "]";
	}

	
}