package com.greenstar.dailyStatusService.entity;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;


/**
 * The persistent class for the daily_status database table.
 * 
 */
@Entity
@Table(name="daily_status")
public class DailyStatus implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="DAILY_STATUS_ID")
	private long dailyStatusId;

	@Temporal(TemporalType.DATE)
	@Column(name="FOR_DATE")
	private Date forDate;

	@Column(name="PARAMETER_ID")
	private long parameterId;

	@Column(name="STUDENT_ID")
	private long studentId;

	//bi-directional many-to-one association to StatusDetail
	/*@ManyToOne*/
	@Column(name="STATUS_ID")
	private long statusDetail;

	public DailyStatus() {
	}

	public long getDailyStatusId() {
		return this.dailyStatusId;
	}

	public void setDailyStatusId(long dailyStatusId) {
		this.dailyStatusId = dailyStatusId;
	}

	public Date getForDate() {
		return this.forDate;
	}

	public void setForDate(Date forDate) {
		this.forDate = forDate;
	}

	public long getParameterId() {
		return this.parameterId;
	}

	public void setParameterId(long parameterId) {
		this.parameterId = parameterId;
	}

	public long getStudentId() {
		return this.studentId;
	}

	public void setStudentId(long studentId) {
		this.studentId = studentId;
	}

	public long getStatusDetail() {
		return this.statusDetail;
	}

	public void setStatusDetail(long statusDetail) {
		this.statusDetail = statusDetail;
	}

}