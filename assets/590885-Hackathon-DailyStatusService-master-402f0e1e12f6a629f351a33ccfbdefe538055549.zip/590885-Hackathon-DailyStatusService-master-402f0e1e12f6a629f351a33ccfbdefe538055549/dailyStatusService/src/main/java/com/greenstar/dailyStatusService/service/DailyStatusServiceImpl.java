package com.greenstar.dailyStatusService.service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.greenstar.dailyStatusService.entity.DailyStatus;
import com.greenstar.dailyStatusService.entity.StatusDetail;
import com.greenstar.dailyStatusService.modal.DailyStatusModal;
import com.greenstar.dailyStatusService.modal.GetStatusModel;
import com.greenstar.dailyStatusService.modal.StatusDetailModal;
import com.greenstar.dailyStatusService.repository.DailyStatusRepository;
import com.greenstar.dailyStatusService.repository.StatusDetailRepository;

@Service
public class DailyStatusServiceImpl implements DailyService {

	@Autowired
	DailyStatusRepository dailyStatusRepository;

	@Autowired
	StatusDetailRepository statusDetailRepository;

	@Override
	@Transactional(rollbackOn = Exception.class)
	public long AddStatus(HashMap<Object, Object> statusModal) throws ParseException {
		long response = 0;
		try {
			DailyStatusModal dailyStatusModal = new DailyStatusModal();
			response = mapDataToModal(dailyStatusModal, statusModal);
		} catch (Exception e) {
			throw e;
		}

		return response;
	}

	private long mapDataToModal(DailyStatusModal dailyStatusModal, HashMap<Object, Object> statusModal)
			throws ParseException {
		long response = 0;
		try {
			String dateTime = String.valueOf(statusModal.get("forDate"));
			Date date = new SimpleDateFormat("yyyy-MM-dd").parse(dateTime);

			StatusDetailModal statusDetailModal = new StatusDetailModal();

			dailyStatusModal.setForDate(date);

			StatusDetail statusDetailEntity = null;
			DailyStatus dailyStatusEntity = null;

			HashMap<String, List<HashMap<String, Integer>>> data = (HashMap<String, List<HashMap<String, Integer>>>) statusModal
					.get("Student");
			for (String studentId : data.keySet()) {
				dailyStatusModal.setStudentId(Long.parseLong(studentId));
				for (HashMap<String, Integer> studentMap : data.get(studentId)) {
					statusDetailEntity = new StatusDetail();
					dailyStatusEntity = new DailyStatus();
					dailyStatusModal.setParameterId(studentMap.get("parameterId"));
					statusDetailModal.setStatusValue("N");
					if (1 == studentMap.get("status_id") || (Integer.valueOf(1)).equals(studentMap.get("status_id"))) {
						statusDetailModal.setStatusValue("Y");
					}

					BeanUtils.copyProperties(statusDetailModal, statusDetailEntity);
					BeanUtils.copyProperties(dailyStatusModal, dailyStatusEntity);

					System.out.println(dailyStatusModal);

					statusDetailEntity = statusDetailRepository.saveAndFlush(statusDetailEntity);
					dailyStatusEntity.setStatusDetail((statusDetailEntity.getStatusId()));
					dailyStatusEntity = dailyStatusRepository.saveAndFlush(dailyStatusEntity);
				}
			}
			response = dailyStatusEntity.getDailyStatusId();
		} catch (Exception e) {
			throw e;
		}

		return response;
	}

	@Override
	public List<GetStatusModel> getStatusById(long studentId) {
		List<GetStatusModel> modalList = new ArrayList<GetStatusModel>();

		List<DailyStatus> dailyStatusEntity = new ArrayList<DailyStatus>();
		StatusDetail statusDetailEntity = new StatusDetail();
		try {
			dailyStatusEntity = dailyStatusRepository.findAllByStudentId(studentId);
			for (DailyStatus element : dailyStatusEntity) {
				GetStatusModel modal = new GetStatusModel();
				statusDetailEntity = statusDetailRepository.getOne(element.getStatusDetail());
				modal.setDailyStatusId(element.getDailyStatusId());
				modal.setForDate(element.getForDate());
				modal.setParameterId(element.getParameterId());
				modal.setStatusDetail(element.getStatusDetail());
				modal.setStatusId(statusDetailEntity.getStatusId());
				modal.setStatusValue(statusDetailEntity.getStatusValue());
				modal.setStudentId(studentId);
				modalList.add(modal);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return modalList;
	}

	@Override
	public List<GetStatusModel> getStatusByStatusValue(String statusValue) {

		List<GetStatusModel> modalList = new ArrayList<GetStatusModel>();
		ArrayList<DailyStatus> dailyStatusEntity = new ArrayList<DailyStatus>();
		ArrayList<StatusDetail> statusDetailEntity = new ArrayList<StatusDetail>();
		try {

			statusDetailEntity = statusDetailRepository.findAllByStatusValue(statusValue);
			for (StatusDetail statusDetailElement : statusDetailEntity) {
				long statusID = statusDetailElement.getStatusId();
				dailyStatusEntity = dailyStatusRepository.findAllByDailyStatusId(statusID);
				for (DailyStatus dailyStatusElement : dailyStatusEntity) {
					GetStatusModel modal = new GetStatusModel();
					modal.setDailyStatusId(dailyStatusElement.getDailyStatusId());
					modal.setForDate(dailyStatusElement.getForDate());
					modal.setParameterId(dailyStatusElement.getParameterId());
					modal.setStatusDetail(dailyStatusElement.getStatusDetail());
					modal.setStatusId(statusDetailElement.getStatusId());
					modal.setStatusValue(statusDetailElement.getStatusValue());
					modal.setStudentId(dailyStatusElement.getStudentId());
					modalList.add(modal);
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return modalList;
	}
}
