package com.greenstar.dailyStatusService.modal;

import java.io.Serializable;

public class StatusDetailModal implements Serializable {
	private static final long serialVersionUID = 1L;

	private String statusValue;

	public StatusDetailModal() {
	}

	public String getStatusValue() {
		return this.statusValue;
	}

	public void setStatusValue(String statusValue) {
		this.statusValue = statusValue;
	}

	@Override
	public String toString() {
		return "StatusDetailModal [statusValue=" + statusValue + "]";
	}

	
}