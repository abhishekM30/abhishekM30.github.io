package com.greenstar.dailyStatusService.controller;

import java.text.ParseException;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.greenstar.dailyStatusService.modal.GetStatusModel;
import com.greenstar.dailyStatusService.service.DailyService;

@RestController
public class DailyStatusController {

	@Autowired
	DailyService dailyService;

	@PutMapping("/dailystatus/add")
	public long putStaus(@RequestBody HashMap<Object, Object> statusModal) throws ParseException {
		long response = 0;
		try {
			response = dailyService.AddStatus(statusModal);
		} catch (Exception e) {
			e.printStackTrace();
		}

		return response;
	}


	@GetMapping("/dailystatus/student/{studentId}")
	public List<GetStatusModel> getStudentById(@PathVariable long studentId) throws ParseException {
		List<GetStatusModel> response = null;
		try {
			response = dailyService.getStatusById(studentId);
		} catch (Exception e) {
			e.printStackTrace();
		}

		return response;

	}

	@GetMapping("/dailystatus/status/{statusValue}")
	public List<GetStatusModel> getStatusByStatus(@PathVariable String statusValue) throws ParseException {
		List<GetStatusModel> response =null;
		try {
			response = dailyService.getStatusByStatusValue(statusValue);
		} catch (Exception e) {
			e.printStackTrace();
		}

		return response;
	
	}
}
