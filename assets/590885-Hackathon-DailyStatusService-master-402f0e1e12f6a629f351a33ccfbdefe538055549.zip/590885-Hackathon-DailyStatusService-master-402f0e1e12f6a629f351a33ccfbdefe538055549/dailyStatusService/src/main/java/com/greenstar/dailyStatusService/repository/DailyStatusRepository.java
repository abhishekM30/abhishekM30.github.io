package com.greenstar.dailyStatusService.repository;

import java.util.ArrayList;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.greenstar.dailyStatusService.entity.DailyStatus;

public interface DailyStatusRepository extends JpaRepository<DailyStatus, Long>{

	ArrayList<DailyStatus> findAllByDailyStatusId(long statusId);

	List<DailyStatus> findAllByStudentId(long studentId);

}
