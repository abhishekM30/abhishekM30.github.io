import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RegisterEditDetailsComponent } from './register-edit-details.component';

describe('RegisterEditDetailsComponent', () => {
  let component: RegisterEditDetailsComponent;
  let fixture: ComponentFixture<RegisterEditDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RegisterEditDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RegisterEditDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
