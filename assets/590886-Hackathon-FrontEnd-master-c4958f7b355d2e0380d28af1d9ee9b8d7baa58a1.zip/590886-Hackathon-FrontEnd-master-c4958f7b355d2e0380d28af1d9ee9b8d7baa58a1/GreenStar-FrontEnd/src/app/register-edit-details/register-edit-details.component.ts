import { Component, OnInit, ViewChild } from '@angular/core';
import { NgModel } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-register-edit-details',
  templateUrl: './register-edit-details.component.html',
  styleUrls: ['./register-edit-details.component.css']
})
export class RegisterEditDetailsComponent implements OnInit {
  @ViewChild('registerEdit') selectCategory: NgModel;
  constructor(private router: Router, private route: ActivatedRoute) { }

  ngOnInit() {
    //console.log(this.route.toString());
  }
  onChange() {
    const relPath = './' + this.selectCategory.value;
    this.router.navigate([relPath], { relativeTo: this.route });
  }
}
