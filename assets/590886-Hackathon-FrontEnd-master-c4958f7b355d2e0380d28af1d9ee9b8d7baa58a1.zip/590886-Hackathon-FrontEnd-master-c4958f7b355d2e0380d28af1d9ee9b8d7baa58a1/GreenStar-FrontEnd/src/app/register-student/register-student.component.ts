import { Component, OnInit } from '@angular/core';
import { ServiceInvoker } from '../Services/ServiceInvoker';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-register-student',
  templateUrl: './register-student.component.html',
  styleUrls: ['./register-student.component.css']
})
export class RegisterStudentComponent implements OnInit {
  schoolArray = [];
  allClassArray = [];
  classArray = [];
  studentRegistrationForm: FormGroup;
  constructor(private serviceInvoker: ServiceInvoker, private router: Router, private route: ActivatedRoute) { }

  ngOnInit() {
    this.createStudentRegistrationForm();
    this.getSchool();
    this.getClass();
  }

  getSchool() {
    this.serviceInvoker.get('http://localhost:4200/api/school-service/school/all').subscribe((data: []) => {
      for (let x of data) {
        this.schoolArray.push({ schoolId: x['schoolId'], schoolName: x['schoolName'] });
      }
    },
      (error) => {
        console.log(error);
      });
  }

  getClass() {
    this.serviceInvoker.get('http://localhost:4200/api/class-details-service/class/all').subscribe((data: []) => {
      this.allClassArray.push(...data);
    },
      (error) => {
        console.log(error);
      });
  }

  createStudentRegistrationForm() {
    this.studentRegistrationForm = new FormGroup({
      'schoolName': new FormControl(null, Validators.required),
      'class': new FormControl(null, Validators.required),
      'studentName': new FormControl(null, [Validators.required, Validators.minLength(3)]),
      'age': new FormControl(null, [Validators.required, Validators.min(1), Validators.max(99), Validators.maxLength(2)]),
      'email': new FormControl(null, [Validators.required, Validators.email, Validators.pattern(/\.\w+$/)]),
      'phone': new FormControl(null, [Validators.required, Validators.min(1000000000), Validators.max(9999999999), Validators.maxLength(10)]),
      'addressLine1': new FormControl(null, Validators.required),
      'district': new FormControl(null, Validators.required),
      'state': new FormControl(null, Validators.required),
      'pincode': new FormControl(null, [Validators.required, Validators.min(100000), Validators.max(999999)])
    });
  }

  onSchoolChange() {
    console.log(this.studentRegistrationForm.get('schoolName').value);
    console.log(this.studentRegistrationForm.get('class'));
    this.classArray = [];
    for (let x of this.allClassArray) {
      if (this.studentRegistrationForm.get('schoolName').value === x['schoolId']) {
        this.classArray.push({ classId: x['classId'], className: x['className'] + '-' + x['classSection'] });
      }
    }
  }

  onClassChange() {
    console.log(this.studentRegistrationForm.get('class'));
  }

  onSubmit() {
    const data = {
      studentId: null,
      classId: this.studentRegistrationForm.get('class').value,
      lastUpdatedBy: 'NA',
      lastUpdatedOn: new Date(),
      softDelete: null,
      softDeleteDate: null,
      studentOldIds: null,
      teamId: 1,
      studentPersonalDetailModal: {
        studentDetailId: null,
        addressId : null,
        age: this.studentRegistrationForm.get('class').value,
        bloodType: 'B+',
        dob: new Date(),
        doj: new Date(),
        firstName: this.studentRegistrationForm.get('studentName').value,
        lastName: 'lastName',
        middleName: 'middleName'
      },
      addressModal: {
        addressId: null,
        addressLine1: this.studentRegistrationForm.get('addressLine1').value,
        district: this.studentRegistrationForm.get('district').value,
        state: this.studentRegistrationForm.get('state').value,
        pinCode: this.studentRegistrationForm.get('pincode').value,
        emergencyContactNo: this.studentRegistrationForm.get('phone').value
      }
    };
    this.serviceInvoker.put('http://localhost:4200/api/student-details-service/student/add', data)
    .subscribe((data) => {
      alert('Student added successfully');
      console.log(data);
      const relPath = './home';
      this.router.navigate([relPath], { relativeTo: this.route });
      
    },
      (error) => {
        console.log(error);
      });
  }
}
