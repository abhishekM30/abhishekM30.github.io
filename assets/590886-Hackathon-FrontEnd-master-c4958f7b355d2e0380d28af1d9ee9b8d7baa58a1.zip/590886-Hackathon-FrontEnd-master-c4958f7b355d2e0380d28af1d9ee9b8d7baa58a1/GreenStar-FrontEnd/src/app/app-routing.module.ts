import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { RegisterSchoolComponent } from './register-school/register-school.component';
import { RegisterClassComponent } from './register-class/register-class.component';
import { RegisterEditDetailsComponent } from './register-edit-details/register-edit-details.component';
import { LoginComponent } from './login/login.component';
import { RegisterStudentComponent } from './register-student/register-student.component';
import { RegisterUserComponent } from './register-user/register-user.component';
import { AuthGuard } from './Services/auth-guard.service';


const appRoutes: Routes = [
  { path: '', redirectTo: '/home', pathMatch: 'full' },
  { path: 'home', component: HomeComponent , canActivate: [AuthGuard]},
  { path: 'login', component: LoginComponent },
  {
    path: 'register', component: RegisterEditDetailsComponent, canActivate: [AuthGuard], children: [
      { path: 'school', component: RegisterSchoolComponent },
      { path: 'class', component: RegisterClassComponent },
      { path: 'student', component: RegisterStudentComponent },
      { path: 'user', component: RegisterUserComponent }
    ]
  },
  {
    path: 'edit', component: RegisterEditDetailsComponent, canActivate: [AuthGuard] ,children: [
      { path: 'school', component: RegisterSchoolComponent },
      { path: 'class', component: RegisterClassComponent },
      { path: 'student', component: RegisterStudentComponent },
      { path: 'user', component: RegisterUserComponent }
    ]
  },
  { path: 'dashboard', component: DashboardComponent , canActivate: [AuthGuard] },
  { path: '**', redirectTo: '/home' }
];

@NgModule({
  imports: [RouterModule.forRoot(appRoutes)],
  exports: [RouterModule]
})
export class AppRoutingModule {

}
