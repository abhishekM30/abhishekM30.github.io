export class AuthService {
  loggedIn = false;

  isAuthenticated() {
    const promise = new Promise(
      (resolve, reject) => {
        if (sessionStorage.getItem('loggedIn') && sessionStorage.getItem('loggedIn') === 'true') {
          this.loggedIn = true;
        } else {
          this.loggedIn = false;
        }
        resolve(this.loggedIn);
      }
    );
    return promise;
  }

  login() {
    sessionStorage.setItem('loggedIn', 'true');
  }

  logout() {
    sessionStorage.removeItem('loggedIn');
  }
}
