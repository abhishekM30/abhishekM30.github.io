import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable()
export class ServiceInvoker {
    constructor(private http: HttpClient) { }

    configUrl = 'assets/config.json';

    get2() {
        return this.http.get(this.configUrl);
    }

    get(url) {
        return this.http.get(url);
    }

    put(url, data) {
        return this.http.put(url, data);
    }

    post(url, data) {
        return this.http.post(url, data);
    }
}