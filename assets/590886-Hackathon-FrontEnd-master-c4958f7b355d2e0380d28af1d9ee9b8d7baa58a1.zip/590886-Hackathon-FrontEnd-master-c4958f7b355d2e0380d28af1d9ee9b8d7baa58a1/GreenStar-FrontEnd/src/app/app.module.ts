import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

import { AppComponent } from './app.component';
import { StarService } from './Services/star.service';
import { SetStarBgColorDirective } from './Directives/set-star-bg-color.directive';
import { MonthlyDetails } from './Services/monthly.details.service';
import { SetStarColorDirective } from './Directives/set-star-color.directive';
import { AppRoutingModule } from './app-routing.module';
import { HeaderComponent } from './header/header.component';
import { HomeComponent } from './home/home.component';
import { RegisterSchoolComponent } from './register-school/register-school.component';
import { RegisterClassComponent } from './register-class/register-class.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { ChangePanelColorDirective } from './Directives/change-panel-color.directive';
import { RegisterEditDetailsComponent } from './register-edit-details/register-edit-details.component';
import { SpinnerComponent } from './spinner/spinner.component';
import { LoginComponent } from './login/login.component';
import { RegisterStudentComponent } from './register-student/register-student.component';
import { ServiceInvoker } from './Services/ServiceInvoker';
import { RegisterUserComponent } from './register-user/register-user.component';
import { EnterDailyStatusComponent } from './enter-daily-status/enter-daily-status.component';

import { AuthService } from './Services/auth.service';
import { AuthGuard } from './Services/auth-guard.service';
import { ClassTableComponent } from './class-table/class-table.component';
import {MatNativeDateModule} from '@angular/material';
import {platformBrowserDynamic} from '@angular/platform-browser-dynamic';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {DemoMaterialModule} from '../material-module';
import { SchoolTableComponent } from './school-table/school-table.component';
import { StudentTableComponent } from './student-table/student-table.component';








@NgModule({
  declarations: [
    AppComponent,
    SetStarBgColorDirective,
    SetStarColorDirective,
    HeaderComponent,
    HomeComponent,
    RegisterSchoolComponent,
    RegisterClassComponent,
    DashboardComponent,
    ChangePanelColorDirective,
    RegisterEditDetailsComponent,
    SpinnerComponent,
    LoginComponent,
    RegisterStudentComponent,
    RegisterUserComponent,
    EnterDailyStatusComponent,
    ClassTableComponent,
    SchoolTableComponent,
    StudentTableComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    BrowserAnimationsModule,
    DemoMaterialModule,
    MatNativeDateModule
  ],
 // entryComponents: [ClassTableComponent],
  providers: [StarService, MonthlyDetails, ServiceInvoker, AuthService, AuthGuard],
  bootstrap: [AppComponent]
})
export class AppModule { }
