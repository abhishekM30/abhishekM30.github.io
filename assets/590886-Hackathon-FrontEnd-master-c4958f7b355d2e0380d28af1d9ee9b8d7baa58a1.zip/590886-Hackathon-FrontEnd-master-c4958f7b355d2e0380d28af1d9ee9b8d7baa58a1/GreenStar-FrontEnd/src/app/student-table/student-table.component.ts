import { Component, OnInit } from '@angular/core';
import { ServiceInvoker } from '../Services/ServiceInvoker';

export interface StudentElement {
  studentId: number;
  classId: number;
  lastUpdatedBy: string;
  lastUpdatedOn:String;
  softDelete: string;
  softDeleteDate: string;
  studentOldIds: string;
  studentPersonalDetailModal:studentPersonalDetailElemet;
  addressModal:addressElement;
}

export interface studentPersonalDetailElemet {
  studentDetailId: number;
  addressId: number;
  age: number;
  bloodType:String;
  dob: string;
  doj: string;
  firstName: string;
  lastName:String;
  middleName:String;
}

export interface addressElement {
  addressId: number;
  addressLine1: string;
  district: string;
  state: string;
  pinCode: number;
  emergencyContactNo: number;

}

//let ELEMENT_DATA: StudentElement[] = [];


@Component({
  selector: 'app-student-table',
  templateUrl: './student-table.component.html',
  styleUrls: ['./student-table.component.css']
})
export class StudentTableComponent implements OnInit {
  displayedColumns: string[] = [ 'firstName','middleName', 'lastName', 'district','state','pinCode'];
  dataSource;
  constructor(private serviceInvoker: ServiceInvoker) { }

  ngOnInit() {
    this.getData(1);
  }
  rowOnClick(row){
    console.log(row);
  }

  getData(id){
    this.serviceInvoker.get('http://localhost:4200/api/student-details-service/student/class/id/'+id)
    .subscribe(
      (data: any[]) => {
        this.dataSource = data;
      },
      (error) => {
        console.log(error);
      });
  }

  

}
