import { Component } from '@angular/core';
import { AuthGuard } from '../Services/auth-guard.service';
import { AuthService } from '../Services/auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html'
})
export class HeaderComponent {
  constructor(private authService: AuthService, private router: Router) { }
  changeHamburgerMenuIcon(hamburgerIcon: HTMLDivElement, hamburgerMenu: HTMLDivElement) {
    hamburgerIcon.classList.toggle('change');
    if (hamburgerMenu.style.display === 'block') {
      hamburgerMenu.style.display = 'none';
    } else {
      hamburgerMenu.style.display = 'block';
    }
  }

  logOut() {
    this.authService.logout();
    this.router.navigate(['/login']);
  }
}
