import { Component, OnInit } from '@angular/core';
import { StarService } from '../Services/star.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  constructor(private starService: StarService) { }
  starPoint: string[];
  starPoint2: string[];
  textPoints;
  monthValues: (string | number)[];
  ngOnInit() {
    this.starPoint = this.starService.points;
    this.starPoint2 = this.starService.points2;
    this.textPoints = this.starService.textPoints;
    this.monthValues = this.starService.getMonthValues();
  }

}
