export interface EvaluationParameterModel {
    id: number;
    parameterName: string;
}