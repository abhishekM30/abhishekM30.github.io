import { AddressModel } from './AddressModel';
import { EvaluationParameterModel } from './evaluationParameterModel';

export interface SchoolModel {
    schoolName: string;
    parameters: EvaluationParameterModel[];
    email: string;
    contactNumber: number;
    address: AddressModel;
}