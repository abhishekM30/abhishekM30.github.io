export interface AddressModel {

    addressLine1: string;
    district: string;
    state: string;
    pinCode: number;
    emergencyContactNo: number;
}