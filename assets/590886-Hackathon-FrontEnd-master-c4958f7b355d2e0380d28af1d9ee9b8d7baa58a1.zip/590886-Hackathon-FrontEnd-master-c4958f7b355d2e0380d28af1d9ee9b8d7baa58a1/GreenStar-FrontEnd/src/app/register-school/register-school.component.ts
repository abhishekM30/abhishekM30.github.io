import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators, FormArray } from '@angular/forms';
import { ServiceInvoker } from '../Services/ServiceInvoker';
import { SchoolModel } from '../Model/SchoolModel';
import { EvaluationParameterModel } from '../Model/evaluationParameterModel';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-register-school',
  templateUrl: './register-school.component.html',
  styleUrls: ['./register-school.component.css']
})

export class RegisterSchoolComponent implements OnInit {
  schoolRegistrationForm: FormGroup;
  hideThisPart: boolean;
  constructor(private serviceInvoker: ServiceInvoker, private router: Router, private route: ActivatedRoute) { }

  ngOnInit() {
    this.hideThisPart = false;
    this.createSchoolRegistrationForm();
    this.addToFormsArray();
  }
  createSchoolRegistrationForm() {
    this.schoolRegistrationForm = new FormGroup({
      'name': new FormControl(null, [Validators.required, Validators.minLength(5)]),
      'email': new FormControl(null, [Validators.required, Validators.email, Validators.pattern(/\.\w+$/)]),
      'phone': new FormControl(null, [Validators.required, Validators.min(1000000000), Validators.max(9999999999), Validators.maxLength(10)]),
      'addressLine1': new FormControl(null, Validators.required),
      'district': new FormControl(null, Validators.required),
      'state': new FormControl(null, Validators.required),
      'pincode': new FormControl(null, [Validators.required, Validators.min(100000), Validators.max(999999)]),
      'evaluationParameters': new FormArray([], Validators.required)
    });
  }
  addToFormsArray() {
    const control = new FormControl(null, Validators.required);
    (<FormArray>this.schoolRegistrationForm.get('evaluationParameters')).push(control);
  }

  removeFromFormsArray(index: number) {
    (<FormArray>this.schoolRegistrationForm.get('evaluationParameters')).removeAt(index);
  }

  onSubmit() {
    console.log(this.schoolRegistrationForm.value);
  }

  getControls() {
    return (<FormArray>this.schoolRegistrationForm.get('evaluationParameters')).controls;
  }

  activateNextButton() {
    if (this.schoolRegistrationForm.get('name').valid &&
      this.schoolRegistrationForm.get('email').valid &&
      this.schoolRegistrationForm.get('phone').valid &&
      this.schoolRegistrationForm.get('addressLine1').valid &&
      this.schoolRegistrationForm.get('district').valid &&
      this.schoolRegistrationForm.get('state').valid &&
      this.schoolRegistrationForm.get('pincode').valid) {
      return false;
    } else {
      return true;
    }
  }

  hideSomeParts() {
    this.hideThisPart = !this.hideThisPart;
  }

  addSchool() {
    const data: SchoolModel = this.makeSchoolModel();
    console.log(data);
    this.serviceInvoker.put('http://localhost:4200/api/school-service/school/add', data)
      .subscribe((data) => {
        alert('School added successfully');
        console.log(data);
        const relPath = './home';
        this.router.navigate([relPath], { relativeTo: this.route });
      },
      (error) =>{
        console.log(error);
      });
  }

  makeSchoolModel(): SchoolModel {
    let evalutionParamneter: EvaluationParameterModel[] = [];
    let zz = 0;
    for (let i of this.schoolRegistrationForm.value.evaluationParameters) {
      evalutionParamneter.push({ id: null, parameterName: i });zz++;
    }

    const data: SchoolModel = {
      schoolName: this.schoolRegistrationForm.value.name,
      parameters: evalutionParamneter,
      email: this.schoolRegistrationForm.value.email,
      contactNumber: this.schoolRegistrationForm.value.phone,
      address: {
        addressLine1: this.schoolRegistrationForm.value.addressLine1,
        district: this.schoolRegistrationForm.value.district,
        state: this.schoolRegistrationForm.value.state,
        pinCode: this.schoolRegistrationForm.value.pincode,
        emergencyContactNo: this.schoolRegistrationForm.value.emergencyContactNo
      }
    }
    return data;
  }
}
