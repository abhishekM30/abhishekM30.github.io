import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EnterDailyStatusComponent } from './enter-daily-status.component';

describe('EnterDailyStatusComponent', () => {
  let component: EnterDailyStatusComponent;
  let fixture: ComponentFixture<EnterDailyStatusComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EnterDailyStatusComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EnterDailyStatusComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
