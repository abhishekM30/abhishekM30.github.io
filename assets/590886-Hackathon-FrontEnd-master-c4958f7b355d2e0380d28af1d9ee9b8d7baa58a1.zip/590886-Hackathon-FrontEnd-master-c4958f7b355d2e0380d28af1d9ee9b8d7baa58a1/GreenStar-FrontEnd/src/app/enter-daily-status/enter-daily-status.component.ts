import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-enter-daily-status',
  templateUrl: './enter-daily-status.component.html',
  styleUrls: ['./enter-daily-status.component.css']
})
export class EnterDailyStatusComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
