import { Component, OnInit } from '@angular/core';
import { ServiceInvoker } from '../Services/ServiceInvoker';

export interface SchoolElement {
  schoolId: number;
  schoolName: string;
  schoolAddressId: string;
  parameters:parametersElement;
  holidays: holidaysElement;
  email: string;
  contactNumber: string;
  address:addressElement;
}

export interface parametersElement {
  id: number;
  parameterName: string;
  schoolId: number;

}

export interface holidaysElement {
  id: number;
  holidayDate: string;
  holidayName: string;
  reason: string;
  schoolId: number;

}

export interface addressElement {
  addressId: number;
  addressLine1: string;
  district: string;
  state: string;
  pinCode: number;
  emergencyContactNo: number;

}

@Component({
  selector: 'app-school-table',
  templateUrl: './school-table.component.html',
  styleUrls: ['./school-table.component.css']
})
export class SchoolTableComponent implements OnInit {
  displayedColumns: string[] = ['schoolName', 'addressLine1', 'district','state','pinCode','email','contactNumber'];
  dataSource;
  constructor(private serviceInvoker: ServiceInvoker) { }

  ngOnInit() {
    this.getData();
  }
  rowOnClick(row){
    console.log(row);
  }

  getData(){
    this.serviceInvoker.get('http://localhost:4200/api/school-service/school/all')
    .subscribe(
      (data: any[]) => {
        this.dataSource = data;
      },
      (error) => {
        console.log(error);
      });
  }

}
