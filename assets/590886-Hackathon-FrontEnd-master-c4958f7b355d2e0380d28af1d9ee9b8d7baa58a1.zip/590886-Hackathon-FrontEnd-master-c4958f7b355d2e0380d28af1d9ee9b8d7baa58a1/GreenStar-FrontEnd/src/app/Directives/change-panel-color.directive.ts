import { Directive, HostBinding, Renderer2, OnInit, ElementRef, HostListener } from '@angular/core';

@Directive({
  selector: '[appChangePanelColor]'
})
export class ChangePanelColorDirective implements OnInit {

  constructor(private render: Renderer2, private elRef: ElementRef) { }
  ngOnInit() {
    this.render.addClass(this.elRef.nativeElement, 'panel-default');
  }
  @HostListener('mouseenter') mouseIn() {
    this.render.removeClass(this.elRef.nativeElement, 'panel-default');
    this.render.addClass(this.elRef.nativeElement, 'panel-primary');
    this.render.addClass(this.elRef.nativeElement, 'shadowBox');
  }
  @HostListener('mouseleave') mouseOut() {
    this.render.removeClass(this.elRef.nativeElement, 'panel-primary');
    this.render.removeClass(this.elRef.nativeElement, 'shadowBox');
    this.render.addClass(this.elRef.nativeElement, 'panel-default');
  }
}
