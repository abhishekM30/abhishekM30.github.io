import { Directive, HostBinding, OnInit, Input } from '@angular/core';

@Directive({
  selector: '[appSetStarColor]'
})
export class SetStarColorDirective implements OnInit {
  @Input('appSetStarColor') dailyData: string | number;
  @HostBinding('style.fill') testColor: string;
  constructor() { }
  ngOnInit() {
    if (this.dailyData && this.dailyData === 'leave') {
      this.testColor = 'white';
    } else {
      this.testColor = 'black';
    }
  }
}
