import { Directive, HostBinding, OnInit, Input } from '@angular/core';

@Directive({
  selector: '[appSetStarBgColor]'
})
export class SetStarBgColorDirective implements OnInit {
  @Input() dayValue: string | number;
  @HostBinding('style.fill') bgColor = 'white';
  constructor() { }
  ngOnInit() {
    if (this.dayValue) {
      if (this.dayValue === 'leave') {
        this.bgColor = 'blue';
      } else if (this.dayValue >= 75) {
        this.bgColor = 'green';
      } else if (this.dayValue >= 50 && this.dayValue < 75) {
        this.bgColor = 'yellow';
      } else if (this.dayValue < 50) {
        this.bgColor = 'red';
      } else {
        this.bgColor = 'white';
      }
    } else {
      this.bgColor = 'white';
    }
  }
}
