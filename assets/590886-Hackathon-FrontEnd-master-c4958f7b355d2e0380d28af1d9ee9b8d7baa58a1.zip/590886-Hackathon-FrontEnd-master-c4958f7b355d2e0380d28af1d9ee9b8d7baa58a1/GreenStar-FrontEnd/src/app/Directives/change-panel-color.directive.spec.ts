import { ChangePanelColorDirective } from './change-panel-color.directive';

describe('ChangePanelColorDirective', () => {
  it('should create an instance', () => {
    const directive = new ChangePanelColorDirective();
    expect(directive).toBeTruthy();
  });
});
