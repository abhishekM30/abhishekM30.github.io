import { Component, OnInit } from '@angular/core';
import { ServiceInvoker } from '../Services/ServiceInvoker';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-register-user',
  templateUrl: './register-user.component.html',
  styleUrls: ['./register-user.component.css']
})
export class RegisterUserComponent implements OnInit {
  userRegistrationForm: FormGroup;
  rolesArray: { roleId: string, roleName: string }[];
  constructor(private serviceInvoker: ServiceInvoker, private router: Router, private route: ActivatedRoute) { }

  ngOnInit() {
    this.createUserRegistrationForm();
    this.getAllRoles();
  }

  createUserRegistrationForm() {
    this.userRegistrationForm = new FormGroup({
      userName: new FormControl(null, [Validators.required, Validators.minLength(3)]),
      role: new FormControl(null, Validators.required),
      password: new FormControl(null, [Validators.required, Validators.minLength(8)]),
      age: new FormControl(null, [Validators.required, Validators.min(1), Validators.max(99), Validators.maxLength(2)])
    });
  }

  getAllRoles() {
    this.rolesArray = [];
    this.serviceInvoker.get('http://localhost:4200/user-api/user/role/all').subscribe((data: []) => {
      this.rolesArray.push(...data);
    },
      (error) => {
        console.log(error);
      });
  }

  onSubmit() {
    const data = {
      age: this.userRegistrationForm.get('age').value,
      bloodType: 'AB+',
      dob: new Date(),
      doj: new Date(),
      firstName: this.userRegistrationForm.get('userName').value,
      middleName: 'NA',
      lastName: 'lastName',
      applicationUser: {
        password: this.userRegistrationForm.get('password').value
      },
      userRole: {
        roleName: this.userRegistrationForm.get('role').value
      }
    };

    this.serviceInvoker.put('http://localhost:4200/user-api/user/add', data).subscribe((data) => {
      alert('User created successfuly, user id is : '+ data);
      console.log(data);
      const relPath = './home';
      this.router.navigate([relPath], { relativeTo: this.route });
    },
      (error) => {
        console.log(error);
      });
  }

}
