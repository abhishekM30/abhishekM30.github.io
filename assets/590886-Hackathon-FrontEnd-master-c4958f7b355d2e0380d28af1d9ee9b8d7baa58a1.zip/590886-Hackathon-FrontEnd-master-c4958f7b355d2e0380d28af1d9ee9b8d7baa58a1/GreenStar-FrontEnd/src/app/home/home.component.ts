import { Component, OnInit, HostBinding } from '@angular/core';
import { ServiceInvoker } from '../Services/ServiceInvoker';
import { Config } from '../Model/Config';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  defaultPanelClass: boolean;
  config: Config;
  constructor(private serviceInvoker: ServiceInvoker) { }
  ngOnInit() {
    this.defaultPanelClass = true;
    this.showConfig();
  }
  onMouseOver(event: HTMLInputElement) {
    this.defaultPanelClass = false;
    console.log(event);
  }
  onMouseOut(event: HTMLDivElement) {
    this.defaultPanelClass = true;
  }

  showConfig() {
    this.serviceInvoker.get2()
      .subscribe((data: Config) => this.config = {
          heroesUrl: data['heroesUrl'],
          textfile:  data['textfile']
      });
  }
}
