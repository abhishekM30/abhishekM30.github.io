import { Component, OnInit } from '@angular/core';
import { ServiceInvoker } from '../Services/ServiceInvoker';

export interface ClassElement {
  classId: number;
  classIncharge: number;
  classNameSection: string;
  className:String;
  classSection: string;
  schoolId: string;
  softDelete: string;
  formationDate:String;

}


@Component({
  selector: 'app-class-table',
  templateUrl: './class-table.component.html',
  styleUrls: ['./class-table.component.css']
})
export class ClassTableComponent implements OnInit {
  displayedColumns: string[] = ['classIncharge', 'className', 'classSection'];
  dataSource;
  constructor(private serviceInvoker: ServiceInvoker) { }

  ngOnInit() {
    this.getData(4);
  }

  rowOnClick(row){
    console.log(row);
  }

  getData(id){
    this.serviceInvoker.get('http://localhost:4200/api/class-details-service/class/school/id/'+id)
    .subscribe(
      (data: any[]) => {
        this.dataSource = data;
      },
      (error) => {
        console.log(error);
      });
  }


}
