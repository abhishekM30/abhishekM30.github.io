import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators, FormArray } from '@angular/forms';
import { ServiceInvoker } from '../Services/ServiceInvoker';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-register-class',
  templateUrl: './register-class.component.html',
  styleUrls: ['./register-class.component.css']
})
export class RegisterClassComponent implements OnInit {
  classRegistrationForm: FormGroup;
  schoolArray: { 'schoolId': number, 'schoolName': string }[];
  classNameSection: string[];
  constructor(private serviceInvoker: ServiceInvoker, private router: Router, private route: ActivatedRoute) { }
  ngOnInit() {
    this.schoolArray = [];
    this.createClassRegistrationForm();
    this.addToFormsArray();
    this.getSchool();
  }
  createClassRegistrationForm() {
    this.classRegistrationForm = new FormGroup({
      'school': new FormControl(null, Validators.required),
      'classes': new FormArray([])
    });
  }

  getControls() {
    return (<FormArray>this.classRegistrationForm.get('classes')).controls;
  }

  addToFormsArray() {
    const control = new FormGroup({
      'class': new FormControl(null, [Validators.required]),
      'section': new FormControl(null, [Validators.required])
    });
    (<FormArray>this.classRegistrationForm.get('classes')).push(control);
  }

  removeFromFormsArray(index: number) {
    (<FormArray>this.classRegistrationForm.get('classes')).removeAt(index);
  }

  onSubmit() {
    this.classNameSection = [];
    for (let z of this.classRegistrationForm.value.classes) {
      this.classNameSection.push(z['class'] + '-' + z['section']);
    }
    const data = {
      'schoolId': this.classRegistrationForm.value.school,
      'classNameSection': this.classNameSection,
      'classIncharge': 'NA',
      'formationDate': new Date()
    };
    this.serviceInvoker.put('http://localhost:4200/api/class-details-service/class/add', data)
      .subscribe((data) => {
        alert('Class added successfully');
        console.log(data);
        const relPath = './home';
        this.router.navigate([relPath], { relativeTo: this.route });
      },
        (error) => {
          console.log(error);
        });
  }

  getSchool() {
    this.serviceInvoker.get('http://localhost:4200/api/school-service/school/all').subscribe((data: []) => {
      for (let x of data) {
        this.schoolArray.push({ 'schoolId': x['schoolId'], 'schoolName': x['schoolName'] });
      }
    },
      (error) => {
        console.log(error);
      });
  }
}
