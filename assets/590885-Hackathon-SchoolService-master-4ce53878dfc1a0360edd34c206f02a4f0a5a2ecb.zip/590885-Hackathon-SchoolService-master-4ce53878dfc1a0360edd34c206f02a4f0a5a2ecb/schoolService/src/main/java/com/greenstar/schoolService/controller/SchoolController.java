package com.greenstar.schoolService.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.greenstar.schoolService.modal.SchoolModal;
import com.greenstar.schoolService.service.SchoolService;

@RestController
public class SchoolController {

	@Autowired
	SchoolService schoolService;

	@GetMapping("school/id/{id}")
	public SchoolModal getSchool(@PathVariable long id) {

		SchoolModal modal = null;

		try {
			modal = schoolService.getSchoolById(id);
		} catch (Exception e) {
			e.printStackTrace(System.err);
		}

		return modal;
	}

	@PutMapping("school/add")
	public long putSchool(@RequestBody SchoolModal schoolModal) {

		long schoolId = 0l;
		try {
			schoolId = schoolService.addSchool(schoolModal);
		} catch (Exception e) {
			e.printStackTrace(System.err);
		}

		return schoolId;
	}

	@GetMapping("school/all")
	public List<SchoolModal> getAllSchool() {
		List<SchoolModal> response = null;
		try {
			response = schoolService.getAllSchool();
		} catch (Exception e) {
			e.printStackTrace(System.err);
		}

		return response;
	}

}
