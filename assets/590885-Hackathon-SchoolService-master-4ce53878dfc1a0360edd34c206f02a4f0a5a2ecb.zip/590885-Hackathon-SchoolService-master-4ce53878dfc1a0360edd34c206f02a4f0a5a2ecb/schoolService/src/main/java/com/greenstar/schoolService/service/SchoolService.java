package com.greenstar.schoolService.service;

import java.util.List;

import com.greenstar.schoolService.modal.SchoolModal;

public interface SchoolService {
	public long addSchool(SchoolModal schoolModal) throws Exception;

	public SchoolModal getSchoolById(long id) throws Exception;

	public List<SchoolModal> getAllSchool() throws Exception;
}
