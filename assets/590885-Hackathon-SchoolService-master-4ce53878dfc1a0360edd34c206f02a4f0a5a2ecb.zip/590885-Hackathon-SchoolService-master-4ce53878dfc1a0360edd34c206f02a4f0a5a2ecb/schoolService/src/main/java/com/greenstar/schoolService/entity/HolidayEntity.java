package com.greenstar.schoolService.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * The persistent class for the holiday_details database table.
 * 
 */
@Entity
@Table(name = "holiday_details")
public class HolidayEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "HOLIDAY_ID")
	private long id;

	@Temporal(TemporalType.DATE)
	@Column(name = "HOLIDAY_DATE")
	private Date holidayDate;

	@Column(name = "HOLIDAY_NAME")
	private String holidayName;

	private String reason;

	@Column(name = "SCHOOL_ID")
	private Long schoolId;

	public HolidayEntity() {
	}

	public long getId() {
		return this.id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public Date getHolidayDate() {
		return this.holidayDate;
	}

	public void setHolidayDate(Date holidayDate) {
		this.holidayDate = holidayDate;
	}

	public String getHolidayName() {
		return this.holidayName;
	}

	public void setHolidayName(String holidayName) {
		this.holidayName = holidayName;
	}

	public String getReason() {
		return this.reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	public Long getSchoolId() {
		return this.schoolId;
	}

	public void setSchoolId(Long schoolDetail) {
		this.schoolId = schoolDetail;
	}

	@Override
	public String toString() {
		return "HolidayEntity [id=" + id + ", holidayDate=" + holidayDate + ", holidayName=" + holidayName + ", reason="
				+ reason + ", schoolId=" + schoolId + "]";
	}

}