package com.greenstar.schoolService.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.greenstar.schoolService.entity.ParameterEntity;

public interface ParameterRepository extends  JpaRepository<ParameterEntity, Long> {

}
