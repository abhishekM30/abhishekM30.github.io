package com.greenstar.schoolService.service;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.greenstar.schoolService.entity.HolidayEntity;
import com.greenstar.schoolService.entity.ParameterEntity;
import com.greenstar.schoolService.entity.SchoolEntity;
import com.greenstar.schoolService.modal.AddressModal;
import com.greenstar.schoolService.modal.HolidayModal;
import com.greenstar.schoolService.modal.ParameterModal;
import com.greenstar.schoolService.modal.SchoolModal;
import com.greenstar.schoolService.repository.HolidayRepository;
import com.greenstar.schoolService.repository.ParameterRepository;
import com.greenstar.schoolService.repository.SchoolRepository;

@Service
public class SchoolServiceImpl implements SchoolService {

	@Autowired
	SchoolRepository schoolRepository;

	@Autowired
	ParameterRepository parameterRepository;

	@Autowired
	HolidayRepository holidayRepository;

	@Autowired
	AddressService addressService;

	@Override
	@Transactional(rollbackOn = Exception.class)
	public long addSchool(SchoolModal schoolModal) throws Exception {
		long response = 0l;
		SchoolEntity schoolEntity = null;

		try {
			schoolEntity = new SchoolEntity();
			BeanUtils.copyProperties(schoolModal, schoolEntity);
			long addId = addressService.putAddress(schoolModal.getAddress());
			schoolEntity.setSchoolAddressId(addId);
			schoolEntity = schoolRepository.saveAndFlush(schoolEntity);
			
			List<ParameterEntity> parameterEntities = new ArrayList<>();
			List<HolidayEntity> holidayEntities = new ArrayList<>();
			if (null != schoolModal.getParameters()) {
				for (ParameterModal parameter : schoolModal.getParameters()) {
					ParameterEntity parameterEntity = new ParameterEntity();
					BeanUtils.copyProperties(parameter, parameterEntity);
					parameterEntity.setSchoolId(schoolEntity.getSchoolId());
					parameterEntities.add(parameterEntity);
				}
				parameterRepository.saveAll(parameterEntities);
				parameterRepository.flush();
			}
			if (null != schoolModal.getHolidays()) {
				for (HolidayModal holiday : schoolModal.getHolidays()) {
					HolidayEntity holidayEntity = new HolidayEntity();
					BeanUtils.copyProperties(holiday, holidayEntity);
					holidayEntity.setSchoolId(schoolEntity.getSchoolId());
					holidayEntities.add(holidayEntity);
				}
				holidayRepository.saveAll(holidayEntities);
				holidayRepository.flush();
			}
			response = schoolEntity.getSchoolId();
		} catch (Exception e) {
			throw e;
		}
		return response;
	}

	@Override
	@Transactional(rollbackOn = Exception.class)
	public SchoolModal getSchoolById(long id) throws Exception {
		SchoolModal schoolModal = null;
		try {
			schoolModal = new SchoolModal();
			SchoolEntity entity = schoolRepository.getOne(id);
			BeanUtils.copyProperties(entity, schoolModal);
			AddressModal addressModal = addressService.getAddress(schoolModal.getSchoolAddressId());
			schoolModal.setAddress(addressModal);

		} catch (Exception e) {
			throw e;
		}
		return schoolModal;
	}

	@Override
	public List<SchoolModal> getAllSchool() throws Exception {
		List<SchoolModal> schoolModals = null;
		try {
			schoolModals = new ArrayList<>();
			List<SchoolEntity> entity = schoolRepository.findAll();
			for (SchoolEntity data : entity) {
				SchoolModal modal = new SchoolModal();
				BeanUtils.copyProperties(data, modal);
				AddressModal addressModal = addressService.getAddress(modal.getSchoolAddressId());
				modal.setAddress(addressModal);
				schoolModals.add(modal);
			}

		} catch (Exception e) {
			throw e;
		}
		return schoolModals;
	}

}
