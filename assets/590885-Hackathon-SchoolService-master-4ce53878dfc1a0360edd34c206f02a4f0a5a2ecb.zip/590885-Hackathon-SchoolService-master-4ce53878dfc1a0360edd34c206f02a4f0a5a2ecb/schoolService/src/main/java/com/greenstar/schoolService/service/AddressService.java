package com.greenstar.schoolService.service;

import java.util.List;

import org.springframework.cloud.netflix.ribbon.RibbonClient;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.greenstar.schoolService.modal.AddressModal;

@FeignClient("zuul-server")
@RibbonClient("address-service")
@RequestMapping("/address-service")
public interface AddressService {

	@GetMapping("/address/id/{id}")
	public AddressModal getAddress(@PathVariable(value = "id") long id);

	@PutMapping("/address/add")
	public long putAddress(@RequestBody AddressModal addressModal);

	@GetMapping("/address/all")
	public List<AddressModal> getAllAddress();

}
