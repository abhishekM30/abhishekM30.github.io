package com.greenstar.schoolService.modal;

import java.util.List;

public class SchoolModal {

	private long schoolId;
	private String schoolName;
	private long schoolAddressId;
	private List<ParameterModal> parameters;
	private List<HolidayModal> holidays;
	private String email;
	private String contactNumber;
	private AddressModal address;


	
	public AddressModal getAddress() {
		return address;
	}

	public void setAddress(AddressModal address) {
		this.address = address;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}

	public long getSchoolId() {
		return schoolId;
	}

	public void setSchoolId(long schoolId) {
		this.schoolId = schoolId;
	}

	public String getSchoolName() {
		return schoolName;
	}

	public void setSchoolName(String schoolName) {
		this.schoolName = schoolName;
	}

	public long getSchoolAddressId() {
		return schoolAddressId;
	}

	public void setSchoolAddressId(long schoolAddressId) {
		this.schoolAddressId = schoolAddressId;
	}

	public List<ParameterModal> getParameters() {
		return parameters;
	}

	public void setParameters(List<ParameterModal> parameters) {
		this.parameters = parameters;
	}

	public List<HolidayModal> getHolidays() {
		return holidays;
	}

	public void setHolidays(List<HolidayModal> holidays) {
		this.holidays = holidays;
	}

	

	public SchoolModal(long schoolId, String schoolName, long schoolAddressId, List<ParameterModal> parameters,
			List<HolidayModal> holidays, String email, String contactNumber,AddressModal address) {
		super();
		this.schoolId = schoolId;
		this.schoolName = schoolName;
		this.schoolAddressId = schoolAddressId;
		this.parameters = parameters;
		this.holidays = holidays;
		this.email = email;
		this.contactNumber = contactNumber;
		this.address = address;
	}

	public SchoolModal() {

	}

	@Override
	public String toString() {
		return "SchoolModal [schoolId=" + schoolId + ", schoolName=" + schoolName + ", schoolAddressId="
				+ schoolAddressId + ", parameters=" + parameters + ", holidays=" + holidays + ", email=" + email
				+ ", contactNumber=" + contactNumber + ", address=" + address + "]";
	}


	

}
