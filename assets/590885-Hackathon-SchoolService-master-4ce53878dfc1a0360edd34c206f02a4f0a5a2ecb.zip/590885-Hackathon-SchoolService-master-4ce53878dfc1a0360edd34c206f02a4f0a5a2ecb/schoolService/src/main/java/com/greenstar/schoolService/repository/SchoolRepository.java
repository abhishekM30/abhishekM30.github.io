package com.greenstar.schoolService.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.greenstar.schoolService.entity.SchoolEntity;

public interface SchoolRepository extends JpaRepository<SchoolEntity, Long> {


}
