package com.greenstar.schoolService.modal;

public class ParameterModal {

	private long id;
	private String parameterName;

	public ParameterModal() {
	}

	public long getId() {
		return this.id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getParameterName() {
		return this.parameterName;
	}

	public void setParameterName(String parameterName) {
		this.parameterName = parameterName;
	}

	@Override
	public String toString() {
		return "ParameterModal [id=" + id + ", parameterName=" + parameterName + "]";
	}

}
