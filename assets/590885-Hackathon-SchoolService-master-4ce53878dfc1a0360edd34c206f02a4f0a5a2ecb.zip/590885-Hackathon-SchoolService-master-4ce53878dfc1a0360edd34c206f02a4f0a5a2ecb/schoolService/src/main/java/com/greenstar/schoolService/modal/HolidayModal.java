package com.greenstar.schoolService.modal;

import java.util.Date;

public class HolidayModal {

	private long id;
	private Date holidayDate;
	private String holidayName;
	private String reason;

	public HolidayModal() {
	}

	public long getId() {
		return this.id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public Date getHolidayDate() {
		return this.holidayDate;
	}

	public void setHolidayDate(Date holidayDate) {
		this.holidayDate = holidayDate;
	}

	public String getHolidayName() {
		return this.holidayName;
	}

	public void setHolidayName(String holidayName) {
		this.holidayName = holidayName;
	}

	public String getReason() {
		return this.reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	@Override
	public String toString() {
		return "HolidayModal [id=" + id + ", holidayDate=" + holidayDate + ", holidayName=" + holidayName + ", reason="
				+ reason + "]";
	}
	
	

}
