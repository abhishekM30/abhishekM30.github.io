package com.greenstar.schoolService.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * The persistent class for the parameter_details database table.
 * 
 */
@Entity
@Table(name = "parameter_details")
public class ParameterEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "PARAMETER_ID")
	private long id;

	@Column(name = "PARAMETER_NAME")
	private String parameterName;

	@Column(name = "SCHOOL_ID")
	private Long schoolId;

	public ParameterEntity() {
	}

	public long getId() {
		return this.id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getParameterName() {
		return this.parameterName;
	}

	public void setParameterName(String parameterName) {
		this.parameterName = parameterName;
	}

	public Long getSchoolId() {
		return this.schoolId;
	}

	public void setSchoolId(Long schoolDetail) {
		this.schoolId = schoolDetail;
	}

	@Override
	public String toString() {
		return "ParameterEntity [id=" + id + ", parameterName=" + parameterName + ", school=" + schoolId + "]";
	}

}