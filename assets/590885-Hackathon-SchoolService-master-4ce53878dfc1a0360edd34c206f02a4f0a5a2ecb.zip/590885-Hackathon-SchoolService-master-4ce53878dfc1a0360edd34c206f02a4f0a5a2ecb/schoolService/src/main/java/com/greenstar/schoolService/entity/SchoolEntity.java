package com.greenstar.schoolService.entity;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 * The persistent class for the school_details database table.
 * 
 */
@Entity
@Table(name = "school_details")
public class SchoolEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "SCHOOL_ID")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long schoolId;

	@Column(name = "SCHOOL_ADDRESS_ID")
	private long schoolAddressId;

	@Column(name = "SCHOOL_NAME")
	private String schoolName;

	// bi-directional many-to-one association to HolidayDetail
	@OneToMany(mappedBy = "schoolId")
	private List<HolidayEntity> holidays;

	// bi-directional many-to-one association to ParameterDetail
	@OneToMany(mappedBy = "schoolId")
	private List<ParameterEntity> parameters;
	
	@Column(name = "EMAIL")
	private String email;
	
	@Column(name = "CONTACT_NUMBER")
	private String contactNumber;

	
	public SchoolEntity() {
	}

	
	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getContactNumber() {
		return contactNumber;
	}


	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}


	public long getSchoolId() {
		return this.schoolId;
	}

	public void setSchoolId(long schoolId) {
		this.schoolId = schoolId;
	}

	public long getSchoolAddressId() {
		return this.schoolAddressId;
	}

	public void setSchoolAddressId(long schoolAddressId) {
		this.schoolAddressId = schoolAddressId;
	}

	public String getSchoolName() {
		return this.schoolName;
	}

	public void setSchoolName(String schoolName) {
		this.schoolName = schoolName;
	}

	public List<HolidayEntity> getHolidays() {
		return this.holidays;
	}

	public void setHolidays(List<HolidayEntity> holidays) {
		this.holidays = holidays;
	}

	public List<ParameterEntity> getParameters() {
		return this.parameters;
	}

	public void setParameters(List<ParameterEntity> parameters) {
		this.parameters = parameters;
	}


	@Override
	public String toString() {
		return "SchoolEntity [schoolId=" + schoolId + ", schoolAddressId=" + schoolAddressId + ", schoolName="
				+ schoolName + ", holidays=" + holidays + ", parameters=" + parameters + ", email=" + email
				+ ", contactNumber=" + contactNumber + "]";
	}
	

	

}