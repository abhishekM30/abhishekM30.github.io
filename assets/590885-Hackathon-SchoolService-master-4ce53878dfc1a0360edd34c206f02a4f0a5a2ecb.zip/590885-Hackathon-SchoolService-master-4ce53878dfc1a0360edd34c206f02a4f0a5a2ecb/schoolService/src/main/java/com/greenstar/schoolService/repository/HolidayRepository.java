package com.greenstar.schoolService.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.greenstar.schoolService.entity.HolidayEntity;

public interface HolidayRepository extends JpaRepository<HolidayEntity, Long> {

}
