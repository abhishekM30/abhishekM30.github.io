package com.greenstar.applicationUserService.modal;

import java.io.Serializable;


public class ApplicationUserModal implements Serializable {
	private static final long serialVersionUID = 1L;

	private String password;


	public ApplicationUserModal() {
	}


	public String getPassword() {
		return this.password;
	}

	public void setPassword(String password) {
		this.password = password;
	}


	public ApplicationUserModal(String password) {
		super();
		this.password = password;
	}

	@Override
	public String toString() {
		return "ApplicationUserModal [ password=" + password + "]";
	}

	
}