package com.greenstar.applicationUserService.service;

import java.util.List;

import com.greenstar.applicationUserService.modal.PersonalDetailModal;
import com.greenstar.applicationUserService.modal.UserRoleModal;

public interface AppUserDetailService {

	long addUser(PersonalDetailModal personalDetailModal);

	PersonalDetailModal getUserById(long id);

	List<PersonalDetailModal> getAllUser();

	List<UserRoleModal> getAllUserRole();

	String login(long userid,String password);

}
