package com.greenstar.applicationUserService.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.greenstar.applicationUserService.modal.PersonalDetailModal;
import com.greenstar.applicationUserService.modal.UserRoleModal;
import com.greenstar.applicationUserService.service.AppUserDetailService;

@RestController
public class AppUserDetailController {

	@Autowired
	private AppUserDetailService appUserDetailService;

	@PutMapping("/user/add")
	public long putUser(@RequestBody PersonalDetailModal personalDetailModal) {
		long response = 0;
		try {
			response = appUserDetailService.addUser(personalDetailModal);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return response;
	}

	@GetMapping("/user/id/{id}")
	public PersonalDetailModal getUser(@PathVariable long id) {
		PersonalDetailModal response = null;
		try {
			response = appUserDetailService.getUserById(id);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return response;
	}

	@GetMapping("/user/all")
	public List<PersonalDetailModal> getAllUser() {
		List<PersonalDetailModal> response = null;
		try {
			response = appUserDetailService.getAllUser();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return response;
	}

	@GetMapping("/user/role/all")
	public List<UserRoleModal> getAllUserRole() {
		List<UserRoleModal> response = null;
		try {
			response = appUserDetailService.getAllUserRole();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return response;
	}

	@GetMapping("/user/login")
	public String login(@RequestParam long userid, @RequestParam String password) {
		String response = null;
		try {
			response = appUserDetailService.login(userid, password);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return response;
	}

}
