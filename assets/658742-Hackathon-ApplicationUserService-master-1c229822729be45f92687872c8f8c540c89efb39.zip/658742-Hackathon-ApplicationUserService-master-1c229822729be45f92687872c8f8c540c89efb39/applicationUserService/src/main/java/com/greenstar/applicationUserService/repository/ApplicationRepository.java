package com.greenstar.applicationUserService.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.greenstar.applicationUserService.entity.ApplicationUser;

public interface ApplicationRepository extends JpaRepository<ApplicationUser, Long>{

}
