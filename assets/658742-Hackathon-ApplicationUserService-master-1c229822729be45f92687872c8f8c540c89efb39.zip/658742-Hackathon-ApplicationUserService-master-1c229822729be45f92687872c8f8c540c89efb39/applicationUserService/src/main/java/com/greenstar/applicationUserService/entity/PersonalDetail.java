package com.greenstar.applicationUserService.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * The persistent class for the personal_details database table.
 * 
 */
@Entity
@Table(name = "personal_details")
public class PersonalDetail implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "PERSONAL_USER_ID")
	private long personalUserId;

	@Column(name = "ADDRESS_ID")
	private long addressId;

	private int age;

	@Column(name = "BLOOD_TYPE")
	private String bloodType;

	@Temporal(TemporalType.DATE)
	private Date dob;

	@Temporal(TemporalType.DATE)
	private Date doj;

	@Column(name = "FIRST_NAME")
	private String firstName;

	@Column(name = "LAST_NAME")
	private String lastName;

	@Column(name = "MIDDLE_NAME")
	private String middleName;

	// bi-directional many-to-one association to ApplicationUser
	// @OneToMany
	// @JoinColumn(name = "PERSONAL_DETAIL_ID")
	// private ApplicationUser applicationUser;

	// bi-directional many-to-one association to UserRole

	@Column(name = "USER_ROLE")
	private long userRole;

	public PersonalDetail() {
	}

	public long getPersonalUserId() {
		return this.personalUserId;
	}

	public void setPersonalUserId(long personalUserId) {
		this.personalUserId = personalUserId;
	}

	public long getAddressId() {
		return this.addressId;
	}

	public void setAddressId(long addressId) {
		this.addressId = addressId;
	}

	public int getAge() {
		return this.age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getBloodType() {
		return this.bloodType;
	}

	public void setBloodType(String bloodType) {
		this.bloodType = bloodType;
	}

	public Date getDob() {
		return this.dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	public Date getDoj() {
		return this.doj;
	}

	public void setDoj(Date doj) {
		this.doj = doj;
	}

	public String getFirstName() {
		return this.firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return this.lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getMiddleName() {
		return this.middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	/*
	 * public ApplicationUser getApplicationUser() { return this.applicationUser; }
	 * 
	 * public void setApplicationUser(ApplicationUser applicationUsers) {
	 * this.applicationUser = applicationUsers; }
	 */

	public long getUserRole() {
		return this.userRole;
	}

	public void setUserRole(long userRole) {
		this.userRole = userRole;
	}

	@Override
	public String toString() {
		return "PersonalDetail [personalUserId=" + personalUserId + ", addressId=" + addressId + ", age=" + age
				+ ", bloodType=" + bloodType + ", dob=" + dob + ", doj=" + doj + ", firstName=" + firstName
				+ ", lastName=" + lastName + ", middleName=" + middleName + "+, userRole=" + userRole + "]";
	}

}