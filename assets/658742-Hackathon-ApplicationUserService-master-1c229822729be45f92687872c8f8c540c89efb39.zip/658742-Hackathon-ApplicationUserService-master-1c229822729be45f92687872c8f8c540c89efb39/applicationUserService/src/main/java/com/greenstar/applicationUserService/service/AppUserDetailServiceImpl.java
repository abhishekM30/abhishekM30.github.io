package com.greenstar.applicationUserService.service;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.greenstar.applicationUserService.entity.ApplicationUser;
import com.greenstar.applicationUserService.entity.PersonalDetail;
import com.greenstar.applicationUserService.entity.UserRole;
import com.greenstar.applicationUserService.modal.PersonalDetailModal;
import com.greenstar.applicationUserService.modal.UserRoleModal;
import com.greenstar.applicationUserService.repository.ApplicationRepository;
import com.greenstar.applicationUserService.repository.PersonalDetailRepository;
import com.greenstar.applicationUserService.repository.UserRoleRepository;

@Service
public class AppUserDetailServiceImpl implements AppUserDetailService {

	@Autowired
	private PersonalDetailRepository personalDetailRepository;

	@Autowired
	private ApplicationRepository appUserDetailRepository;

	@Autowired
	private UserRoleRepository userRoleRepository;
	@Autowired
	private AddressService addressService;

	@Override
	@Transactional(rollbackOn = Exception.class)
	public long addUser(PersonalDetailModal personalDetailModal) {
		PersonalDetail personalDetailEntity = null;
		ApplicationUser applicationUserEntity = null;
		UserRole userRoleEntity = null;
		long response = 0;
		try {
			personalDetailEntity = new PersonalDetail();
			applicationUserEntity = new ApplicationUser();

			userRoleEntity = userRoleRepository.getUserRoleByRoleName(personalDetailModal.getUserRole().getRoleName());
			
			BeanUtils.copyProperties(personalDetailModal, personalDetailEntity);
			
			long addressId = addressService.putAddress(personalDetailModal.getAddress());
			personalDetailEntity.setAddressId(addressId);
			personalDetailEntity.setUserRole(userRoleEntity.getRoleId());
			personalDetailEntity = personalDetailRepository.saveAndFlush(personalDetailEntity);
			
			BeanUtils.copyProperties(personalDetailModal.getApplicationUser(), applicationUserEntity);
			applicationUserEntity.setPersonalDetail(personalDetailEntity.getPersonalUserId());
			appUserDetailRepository.saveAndFlush(applicationUserEntity);
			response = applicationUserEntity.getAppUserId();
		} catch (Exception e) {
			throw e;
		}
		return response;
	}

	@Override
	@Transactional(rollbackOn = Exception.class)
	public PersonalDetailModal getUserById(long id) {

		PersonalDetail personalDetailEntity = null;
		PersonalDetailModal modal = new PersonalDetailModal();
		try {
			personalDetailEntity = personalDetailRepository.getOne(id);
			BeanUtils.copyProperties(personalDetailEntity, modal);
		} catch (Exception e) {
			throw e;
		}
		return modal;
	}

	@Override
	@Transactional(rollbackOn = Exception.class)
	public List<PersonalDetailModal> getAllUser() {

		List<PersonalDetail> personalDetailEntity = null;
		List<PersonalDetailModal> listModal = null;
		try {
			listModal = new ArrayList<>();
			personalDetailEntity = personalDetailRepository.findAll();
			for (PersonalDetail pd : personalDetailEntity) {
				PersonalDetailModal modal = new PersonalDetailModal();
				BeanUtils.copyProperties(pd, modal);
				listModal.add(modal);
			}
		} catch (Exception e) {
			throw e;
		}
		return listModal;
	}

	@Override
	@Transactional(rollbackOn = Exception.class)
	public List<UserRoleModal> getAllUserRole() {
		List<UserRole> entity = null;
		List<UserRoleModal> modalList = null;
		
		try {
			modalList = new ArrayList<>();
			entity = userRoleRepository.findAll();
			for (UserRole userRole : entity) {
				UserRoleModal modal = new UserRoleModal();
				BeanUtils.copyProperties(userRole, modal);
				modalList.add(modal);
			}
		} catch (Exception e) {
			throw e;
		}

		return modalList;
	}

	@Override
	@Transactional(rollbackOn = Exception.class)
	public String login(long userid, String password) {
		String response = "Unsuccessful login";
		ApplicationUser entity = new ApplicationUser();
		try {
			entity = appUserDetailRepository.getOne(userid);
			if (entity.getPassword().equals(password)) {
				response = "Successful login";
			}
		} catch (Exception e) {
			response = "Unsuccessful login";
		}

		return response;
	}

}
