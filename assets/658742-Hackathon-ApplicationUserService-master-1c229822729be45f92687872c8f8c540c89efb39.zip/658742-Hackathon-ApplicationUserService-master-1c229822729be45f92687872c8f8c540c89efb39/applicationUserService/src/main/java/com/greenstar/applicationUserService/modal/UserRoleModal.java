package com.greenstar.applicationUserService.modal;

import java.io.Serializable;

public class UserRoleModal implements Serializable {
	private static final long serialVersionUID = 1L;

	private long roleId;

	private String roleName;

	// private PersonalDetailModal personalDetails;

	public UserRoleModal() {
	}

	public long getRoleId() {
		return this.roleId;
	}

	public void setRoleId(long roleId) {
		this.roleId = roleId;
	}

	public String getRoleName() {
		return this.roleName;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

	/*
	 * public PersonalDetailModal getPersonalDetails() { return
	 * this.personalDetails; }
	 * 
	 * public void setPersonalDetails(PersonalDetailModal personalDetails) {
	 * this.personalDetails = personalDetails; }
	 */

	/*
	 * public PersonalDetailModal addPersonalDetail(PersonalDetailModal
	 * personalDetail) { getPersonalDetails().add(personalDetail);
	 * personalDetail.setUserRoleBean(this);
	 * 
	 * return personalDetail; }
	 * 
	 * public PersonalDetailModal removePersonalDetail(PersonalDetailModal
	 * personalDetail) { getPersonalDetails().remove(personalDetail);
	 * personalDetail.setUserRoleBean(null);
	 * 
	 * return personalDetail; }
	 */

	public UserRoleModal(long roleId, String roleName) {
		super();
		this.roleId = roleId;
		this.roleName = roleName;
		// this.personalDetails = personalDetails;
	}

	@Override
	public String toString() {
		return "UserRoleModal [roleId=" + roleId + ", roleName=" + roleName + "]";
	}

}