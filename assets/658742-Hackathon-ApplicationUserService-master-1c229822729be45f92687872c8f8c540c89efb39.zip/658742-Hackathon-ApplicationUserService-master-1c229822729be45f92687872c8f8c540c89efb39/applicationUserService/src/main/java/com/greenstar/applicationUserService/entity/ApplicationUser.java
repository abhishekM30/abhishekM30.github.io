package com.greenstar.applicationUserService.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * The persistent class for the application_users database table.
 * 
 */
@Entity
@Table(name = "application_users")
public class ApplicationUser implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "APP_USER_ID")
	private long appUserId;

	private String password;
	
	@Column(name = "PERSONAL_DETAIL_ID")
	private long personalDetail;

	public ApplicationUser() {
	}

	public long getAppUserId() {
		return this.appUserId;
	}

	public void setAppUserId(long appUserId) {
		this.appUserId = appUserId;
	}

	public String getPassword() {
		return this.password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public long getPersonalDetail() {
		return this.personalDetail;
	}

	public void setPersonalDetail(long personalDetail) {
		this.personalDetail = personalDetail;
	}

	@Override
	public String toString() {
		return "ApplicationUser [appUserId=" + appUserId + ", password=" + password + ", personalDetail="
				+ personalDetail + "]";
	}
	

}