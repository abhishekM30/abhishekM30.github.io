package com.greenstar.applicationUserService.modal;

import java.util.Date;

public class PersonalDetailModal {

	private long addressId;

	private int age;

	private String bloodType;

	private Date dob;

	private Date doj;

	private String firstName;

	private String lastName;

	private String middleName;

	private ApplicationUserModal applicationUser;

	private UserRoleModal userRole;

	private AddressModal address;

	public PersonalDetailModal() {
	}

	public long getAddressId() {
		return this.addressId;
	}

	public void setAddressId(long addressId) {
		this.addressId = addressId;
	}

	public int getAge() {
		return this.age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getBloodType() {
		return this.bloodType;
	}

	public void setBloodType(String bloodType) {
		this.bloodType = bloodType;
	}

	public Date getDob() {
		return this.dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	public Date getDoj() {
		return this.doj;
	}

	public void setDoj(Date doj) {
		this.doj = doj;
	}

	public String getFirstName() {
		return this.firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return this.lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getMiddleName() {
		return this.middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public ApplicationUserModal getApplicationUser() {
		return this.applicationUser;
	}

	public void setApplicationUser(ApplicationUserModal applicationUsers) {
		this.applicationUser = applicationUsers;
	}

	public UserRoleModal getUserRole() {
		return this.userRole;
	}

	public void setUserRole(UserRoleModal userRoleBean) {
		this.userRole = userRoleBean;
	}

	public AddressModal getAddress() {
		return address;
	}

	public void setAddress(AddressModal address) {
		this.address = address;
	}

	@Override
	public String toString() {
		return "PersonalDetailModal [ addressId=" + addressId + ", age=" + age + ", bloddType=" + bloodType + ", dob="
				+ dob + ", doj=" + doj + ", firstName=" + firstName + ", lastName=" + lastName + ", middleName="
				+ middleName + ", applicationUsers=" + applicationUser + ", userRoleBean=" + userRole + "]";
	}

}