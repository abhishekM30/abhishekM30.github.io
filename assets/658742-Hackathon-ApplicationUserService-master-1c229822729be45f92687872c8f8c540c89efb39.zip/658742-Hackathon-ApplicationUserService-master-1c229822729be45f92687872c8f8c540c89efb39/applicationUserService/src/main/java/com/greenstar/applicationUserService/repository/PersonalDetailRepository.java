package com.greenstar.applicationUserService.repository;


import org.springframework.data.jpa.repository.JpaRepository;

import com.greenstar.applicationUserService.entity.PersonalDetail;

public interface PersonalDetailRepository extends JpaRepository<PersonalDetail, Long>{

}
